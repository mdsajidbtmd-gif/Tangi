import express from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { DEFAULT_SETTINGS } from './src/utils/starterData.ts';
import { AppState } from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'tailor_shop.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getInitialState(): AppState {
  return {
    officerOrders: [],
    airmanOrders: [],
    deletedOfficerOrders: [],
    deletedAirmanOrders: [],
    customers: [],
    drafts: [],
    workers: [],
    workerRows: [],
    workerPayments: [],
    settings: DEFAULT_SETTINGS,
  };
}

function loadState(): AppState {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      const initial = getInitialState();
      return {
        ...initial,
        ...parsed,
        deletedOfficerOrders: parsed.deletedOfficerOrders || [],
        deletedAirmanOrders: parsed.deletedAirmanOrders || [],
        settings: {
          ...DEFAULT_SETTINGS,
          ...(parsed.settings || {}),
          branchValues: parsed.settings?.branchValues || DEFAULT_SETTINGS.branchValues,
          airmanItems: parsed.settings?.airmanItems || DEFAULT_SETTINGS.airmanItems,
          workItems: parsed.settings?.workItems && parsed.settings.workItems.length >= 50
            ? parsed.settings.workItems
            : DEFAULT_SETTINGS.workItems,
          ribbonValues: parsed.settings?.ribbonValues && parsed.settings.ribbonValues.length >= 10
            ? parsed.settings.ribbonValues
            : DEFAULT_SETTINGS.ribbonValues,
          runningYears: parsed.settings?.runningYears && parsed.settings.runningYears.length >= 3
            ? parsed.settings.runningYears
            : DEFAULT_SETTINGS.runningYears,
        },
      };
    }
  } catch (err) {
    console.error('Error loading data file, initializing fresh:', err);
  }
  const init = getInitialState();
  saveState(init);
  return init;
}

function saveState(state: AppState): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving data file:', err);
  }
}

// Memory cache of state
let currentState: AppState = loadState();

app.use(express.json({ limit: '20mb' }));

// API Routes
app.get('/api/state', (_req, res) => {
  res.json(currentState);
});

app.post('/api/state', (req, res) => {
  const updated = req.body as Partial<AppState>;
  currentState = {
    ...currentState,
    ...updated,
    settings: {
      ...currentState.settings,
      ...(updated.settings || {}),
    },
  };
  saveState(currentState);
  res.json({ success: true, state: currentState });
});

// Reset endpoint for testing if needed
app.post('/api/reset', (_req, res) => {
  currentState = getInitialState();
  saveState(currentState);
  res.json({ success: true, state: currentState });
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';
  const server = http.createServer(app);

  if (!isProduction) {
    // Mount Vite dev server in middleware mode
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production build
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Raymond running on port ${PORT} (isProduction: ${isProduction})`);
  });
}

startServer();
