# Loop 7 — Staff Management and Staff Summary (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 to 6 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** every Officer and Airman screen, Customers, Drafts, print pages, and Settings except the one addition below.

**EXTEND (change in place):**
- **Navigation:** add **Staff Management** and **Staff Summary** before Settings (after Customer History).
- **Settings:** add the **Work Items & Rates** section.

**NEW:** the **Workers list**, the **Worker page** (month picker and Entry List grid), **Staff Summary** with its **Details** panel and **Edit Khoroch** panel, and the **worker statement** print page. Reuse the existing cards, search, tabs, dialogs, and print preview page.

## 1. Purpose and rules for the builder

Loop 7 adds the **workers** who make the clothes. The owner gives each worker pieces of work every month (an order number, an item, a quantity) and the app keeps the monthly **hishab**: how much the worker earned, how much **Khoroch** (advance or expense money) was given to him, and what is left to pay. It adds two screens: **Staff Management** (the workers list and each worker's monthly work sheet) and **Staff Summary** (totals for all workers over a period).

All workers have the same single job, making the clothes. There are no roles, no salary and no percentage. A worker earns the **full item rate** for each piece.

This loop **overrides** these PRD non-goals, for the staff screens only: staff management, staff summary, "khoroch" pages, and Export buttons (CSV and PDF) on the staff screens. Everything else in the PRD still holds.

**Rules**

- Build only what is written here, on top of Loops 1 to 6. Do not change Officer or Airman behaviour.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- There is **no login**. Every user can add, edit and delete.
- Money is in taka (৳). Never write the word "optional" anywhere in the screen text.
- All number boxes (Serial, Quantity, Unit Price, Khoroch) open the numeric keypad on phones.
- Every screen has loading placeholders and a friendly empty message.

## 2. What is new in this loop

1. **Staff Management:** the Workers list.
2. **Worker page:** a month picker and an Entry List grid where work and Khoroch are entered.
3. **Staff Summary:** cards, a period filter and a per-worker table with Details and Khoroch editing.
4. **Work Items & Rates** in Settings.

## 3. What changes from earlier loops

- Navigation gets two links, in this order after Customer History: **Staff Management** and **Staff Summary**.
- **Settings** gets a new section, **Work Items & Rates** (section 7).
- Nothing else changes. Officer and Airman orders, customers, drafts and printing stay as they are.

## 4. Staff Management: Workers list

### 4.1 The list

- Title **Workers**, a count badge ("39 workers"), a search box (English or Bangla name) and an **Add** button.
- One row per worker: serial number (1, 2, 3 …), **English name**, **Bangla name** in brackets, an **Edit** icon and a **Delete** icon.
- Tapping a row opens that worker's page (section 5).
- Workers are listed in the order they were added.

### 4.2 Add and edit

- **Add** opens an inline row at the top with two boxes, **Name** and **Bangla Name**, and ✓ and ✕ buttons.
- **Edit** opens the same two boxes on that row, plus an **Active** switch.
- To save: the English **Name** is required. Bangla Name can be left blank. Two workers may not have the same English name (show "This worker already exists.").
- An **inactive** worker is hidden from the list unless a **Show inactive** switch is on, and does not count in Total Staff. His old data stays.

### 4.3 Delete

- Delete asks for confirmation.
- A worker who has any work, Khoroch or payments **cannot be deleted**. Show: "This worker has records. Set him inactive instead."

## 5. Worker page

### 5.1 Top of the page

- Back arrow, the worker's **English name** and **Bangla name**.
- A **Month** picker, defaulting to the running month. Past months can be picked. The page always shows one month at a time.
- A search box **Search by name or item** that filters the rows below (order number, BD number, customer name or item).
- Buttons: **Recalculate**, **CSV**, **PDF** (section 5.5).

### 5.2 Entry List grid

A card titled **Entry List** with the buttons **Add 10 Rows** and **Save**. Columns, in this order:

| Column | Behaviour |
|---|---|
| **Date** | A date picker. Defaults to today when the picked month is the running month, otherwise to the last day of the picked month. It must fall inside the picked month. |
| **Serial** | The **order number**. See 5.3. |
| **BD Number** | Fills from the order. Can also be typed. |
| **Name** | The **customer name**. Fills from the order. Can also be typed. |
| **Item** | A searchable dropdown of the **Work Items** (section 7). |
| **Quantity** | Defaults to 1. Whole numbers. |
| **Unit Price** | Fills from the item's rate when an item is picked. Can be changed on the row. |
| **Total Taka** | Quantity × Unit Price. Automatic, cannot be typed. |
| **Khoroch Date** | A date picker for the Khoroch given on this row. |
| **Khoroch** | An amount in taka. Default 0. |

- Each row has a small **delete** icon at its end.
- **Add 10 Rows** adds ten blank rows at the bottom. A new worker page starts with ten blank rows.
- The grid scrolls sideways on a phone. The header row stays visible while scrolling down.
- **Footer:** **Total** (sum of Total Taka), **Total Khoroch** (sum of Khoroch) and **Net Payable** (Total − Total Khoroch).

### 5.3 Entering the order number

When a Serial is typed:

1. If an order with that number exists in **only one** category (Officer or Airman), fill **BD Number** and **Name** from it automatically.
2. If it exists in **both**, show a small choice, "Officer #583 · name" and "Airman #583 · name". Tapping one fills the row.
3. If it exists in **neither**, leave the other boxes as they are. The owner can type BD Number and Name by hand. The row can still be saved.

The row **keeps a copy** of the order number, BD number and name as they were when entered. Orders get renumbered when an order is deleted (PRD section 5), so these copies never change afterwards.

### 5.4 Saving rules

- **Save** stores every row that has something in it. Completely blank rows are ignored.
- A row is a **work row** if it has an Item. A work row needs an Item and a Quantity above 0.
- A row with **only** a Khoroch amount (and a Khoroch Date) is a **Khoroch row**. It needs a Khoroch Date. Use it to record an advance that is not tied to any piece of work.
- A row can be both: a piece of work and a Khoroch on the same line.
- A row with a Khoroch amount but no Khoroch Date gets the row's Date.
- Otherwise show a clear message naming the row and what is missing, and do not save that row's data.
- Saved rows reload in the grid, editable in place. Changing a row and pressing **Save** updates it. If the owner leaves the page with unsaved changes, ask first.
- Changing a Work Item's rate later never changes saved rows (the price is copied onto the row).
- A row belongs to the month of its **Date**. Khoroch belongs to the month of its **Khoroch Date**.

### 5.5 Recalculate, CSV and PDF

- **Recalculate** reads the saved rows again and refreshes every total on the page, then shows "Totals recalculated". Totals are always automatic, so this is a safety button.
- **CSV** downloads the picked month's saved rows (every grid column) and the totals.
- **PDF** opens a printable **worker statement**: worker name, month, all rows, Total, Total Khoroch and Net Payable. It uses the paper size from Settings.

## 6. Staff Summary

### 6.1 Top

- Title **Staff Summary**, subtitle "Per-staff work totals", and buttons **Recalculate** and **CSV**.
- **Cards** (two rows of two on a phone): **Total Staff** (active workers), **Total Amount**, **Total Khoroch**, **Total Payable** (the sum of every worker's Net Payable).
- Tapping a card scrolls to the table.

### 6.2 Filters

- A search box for the worker name.
- A **Period** dropdown: **Today**, **This Week**, **Last Week**, **This Month** (default), **Last Month**, **Pick Month** (opens a month picker), **All Time**.
- Work is counted by the row's Date, and Khoroch by the Khoroch Date, both inside the chosen period.

### 6.3 Table

Title **Staff Summary** with a count badge. Columns: **#**, **Staff Name** (English, with the Bangla name under it), **Works** (total quantity of pieces), **Total Amount**, **Khoroch** (orange), **Net Payable** (bold), **Details**, **Edit**.

- Active workers are listed. An inactive worker also appears when he has work or Khoroch in the chosen period.
- Net Payable below 0 (more Khoroch than earnings) is shown in red with a minus sign.
- A totals row at the bottom repeats the four card values.
- **CSV** downloads this table for the chosen period.

### 6.4 Details

**Details** opens a panel for that worker and the chosen period:

- A line of totals: Works, Total Amount, Khoroch, Net Payable.
- **By item:** a small table of item, quantity, amount.
- **Entries:** the saved rows (date, serial, BD number, name, item, quantity, unit price, total, Khoroch date, Khoroch), read-only.
- A button **Open Worker Page** that opens the worker page on the month of the period (the running month when the period is not a single month).

### 6.5 Edit Khoroch

**Edit** opens a panel titled with the worker's name and the month (the month of the period, or a month picker when the period is not a single month):

- A list of all Khoroch for that month: date, amount, a short **Note** and edit and delete icons.
- **Add Khoroch**: Date (today by default), Amount, Note. Saving adds a Khoroch row to the worker's sheet.
- Khoroch typed in the worker grid and Khoroch added here are the **same records**. Editing in either place changes both. Deleting a Khoroch here clears only its Khoroch part; any work on that row stays.
- A total of Khoroch for the month is shown at the bottom.

## 7. Settings: Work Items & Rates

- A new section in Settings: a list of **Work Items**, each with a **Name** and a **Rate** (taka). Add, edit and remove.
- The list **starts as a copy of the Items & Prices list** (same names, each rate equal to the price), once, when this loop is installed. After that it is independent: changing a customer price does not change a Work Item rate, and the other way round.
- The owner adds the Airman items he pays for (for example "Airman Pant") here, with their rates. Airman items in the customer item list have no prices, so they are not copied with a rate. They start at ৳0 and can be edited.
- Removing a Work Item never changes saved rows.

## 8. Money rules

- **Total Taka** (a row) = Quantity × Unit Price.
- **Total Amount** (a worker, a period) = sum of Total Taka.
- **Khoroch** (a worker, a period) = sum of Khoroch amounts.
- **Net Payable** = Total Amount − Khoroch. It is calculated and cannot be typed.
- There is no percentage and no salary.
- Received, Due and Status are **not** in this loop (they come with payments in Loop 8).

## 9. User flows

**A. Give a worker work.** Staff Management → tap Rashid → running month is selected → in a blank row type Serial 584 → BD number and name fill in → pick the item → Quantity 2 → Unit Price fills → Save.

**B. Add ten more rows.** Add 10 Rows → fill → Save.

**C. Past month.** Pick last month → see that month's rows and totals → correct a row → Save.

**D. Same order number in both categories.** Type 583 → choose Airman or Officer from the small choice.

**E. Give an advance.** Staff Summary → Edit on Rashid → Add Khoroch → date, amount, note → Save. Net Payable drops.

**F. Month review.** Staff Summary → Last Month → read each worker's Works, Total Amount, Khoroch and Net Payable → Details on one worker.

**G. Print a statement.** Worker page → PDF.

**H. New worker.** Staff Management → Add → English and Bangla names → ✓.

## 10. Not in this loop (do not build)

Received, Due, Status, Pay and History on Staff Summary (Loop 8). Staff numbers on the Dashboard (Loop 8). Bangla language switch and Bangla digits, dark mode, install as an app, backup, login and security (later loop). Salary, percentage pay, attendance, worker phone or photo, worker roles, notifications, any online payment, and any Export button outside the staff screens.

## 11. Choices I made, to confirm

1. **Serial** is the order number. The BD Number is added as its own column, since the reference grid has no such column.
2. Staff pay is the **full item rate**, taken from a separate **Work Items & Rates** list because Airman items have no customer price.
3. Work Items start as a copy of the customer item list, then stay independent.
4. Rows keep **copies** of order number, BD number and name, because deleting an order renumbers later orders.
5. Khoroch lives on the grid rows and in the Summary Edit panel as one set of records.
6. A row belongs to the month of its Date, and Khoroch to the month of its Khoroch Date.
7. Net Payable can go negative and is then shown in red.
8. A worker with records is set inactive, never deleted.
9. This Week and Last Week run **Saturday to Friday**.
10. Details shows an **item-by-item** breakdown as an extra.
11. CSV and PDF exist only on the staff screens.
12. The little arrow on each row of the reference Workers list is left out.

## 12. Done checklist (test in this order)

1. Staff Management is empty at first with a friendly message. Add a worker with an English and a Bangla name. Adding the same English name again is refused.
2. Open the worker page: ten blank rows, the running month, a footer with all zeros.
3. Type a Serial that exists only as an Officer order: BD Number and Name fill in. Do the same with an Airman-only number. Type a number that exists in both: the choice appears.
4. Type a Serial that does not exist: you can type BD Number and Name by hand and save.
5. Pick an item: Unit Price fills. Change it on the row. Total Taka updates and the footer totals update.
6. Save with an Item but no Quantity: refused with a clear message. Save with only a Khoroch and no Khoroch Date: it takes the row's Date. Blank rows are ignored.
7. Save, leave and return: the rows are there and editable. Leave with unsaved changes: a warning appears.
8. Pick a past month: only that month's rows show. A Date outside the picked month is refused.
9. Search by customer name, order number and item: rows filter.
10. Change a Work Item rate in Settings: saved rows keep their old price.
11. Delete an Officer order that the worker's row points to: the row still shows its old number and name.
12. Staff Summary: the cards and table match the sum of the worker pages. Try every Period option. Net Payable = Total Amount − Khoroch. A worker with more Khoroch than earnings shows a red minus.
13. Details shows the totals, the by-item table and the entries. Open Worker Page opens the right month.
14. Edit Khoroch: add, change and delete Khoroch. The same Khoroch appears in the worker grid.
15. Delete a worker who has records: refused. Set him inactive: he disappears from the list and from Total Staff, and his old data stays.
16. CSV on the worker page and on Staff Summary download the right numbers. PDF shows a worker statement.
17. Recalculate shows "Totals recalculated" and the numbers do not change.
18. Officer and Airman screens are unchanged.
19. The word "optional" appears nowhere.
