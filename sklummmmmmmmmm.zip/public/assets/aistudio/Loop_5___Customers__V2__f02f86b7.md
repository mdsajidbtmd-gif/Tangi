# Loop 5 — Customers (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 to 4 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** Orders screen, order cards, form fields, Order Details, Delivery, print pages, Drafts, Settings.

**EXTEND (change in place):**
- **Navigation:** add **Customers** and **Customer History** links before Settings (after Drafts).
- **New / Edit Order form:** add name and BD-number **suggestions** while typing, and the saved-name message.

**NEW:** the **Customers** screen (card grid, search, sort, Add Customer), the Add and Edit Customer forms, the **Customer History** list, and a **person history** screen. The person's order rows reuse the existing order card style.

## 1. Purpose and rules for the builder

Loop 5 gives the owner a place to see, add, edit and look up Officer customers, and makes typing a customer into a new order faster. When customers can be listed, searched, added, edited, checked for history, and picked while typing an order, the loop is done.

**Rules**

- Build only what is written here, on top of Loops 1 to 4. Do not change earlier behaviour except where section 3 says so.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- Officer customers only. The Airman tab comes with Airman orders in a later loop.
- Never write the word "optional" anywhere in the screen text.
- No Export button anywhere.

## 2. What is new in this loop

1. A **Customers** screen.
2. A **Customer History** screen.
3. **Add Customer**, **Edit Customer** and **Delete Customer**.
4. **Name suggestions** while typing a customer on the order form.

## 3. What changes from earlier loops

- Navigation gets two links: **Customers** and **Customer History**.
- On the New / Edit Order form, typing in Customer Name or BD Number shows suggestions (section 7).
- The rule "existing BD number wins" is now stated clearly (section 7).

## 4. Customers screen

- Tabs at the top: **Officer** (the only tab for now).
- A search box: name, phone or BD number. A sort dropdown: Newest first, Name A–Z, Most due first.
- A button **Add Customer**.
- A grid of customer cards. Each card shows:
  - name, phone (when there is one), BD number
  - three small numbers: **Orders** (how many), **Spent**, **Due** (red when above 0)
  - three icons: **History**, **Edit**, **Delete**
- **Spent** = the total of every order’s Total minus Discount, for all that customer’s orders.
- **Due** = the sum of Due on all that customer’s orders, whatever their status.
- Empty state: "No customers yet. They are added automatically when you save an order."

## 5. Add, edit and delete

### 5.1 Add Customer

- A small form: **BD Number**, **Name**, **Phone** (can be left blank). Save and Cancel buttons.
- BD Number and Name are required. If the BD number already exists, do not save and show: "This BD number already belongs to NAME."

### 5.2 Edit Customer

- The **name** and **phone** can be changed.
- The **BD number cannot be changed.** Show it as plain text.
- Saving updates the name and phone on **all of that customer’s existing orders**, so lists and printed papers match.

### 5.3 Delete Customer

- If the customer has **any orders**, do not delete. Show: "This customer has N orders. Delete those orders first."
- If the customer has no orders, ask once: "Delete this customer?" with Cancel and Delete. Deleting is permanent.

## 6. Customer History screen

- A searchable list of every Officer customer, each row showing name, BD number, and three small numbers: Orders, Spent, Due.
- Tapping a person opens **their history**: all their orders, newest first, each showing order number, order date, status badge, Total and Due. Tapping an order opens Order Details.
- At the top of a person’s history: name, BD number, phone, and the same Orders, Spent and Due numbers.
- The **History** icon on a Customers card opens this same person’s history.

## 7. Suggestions and the BD number rule on the order form

- While typing in **Customer Name** or **BD Number**, show a short list of matching saved Officer customers (name and BD number). Tapping one fills **name, BD number and phone**.
- **The BD number is the identity.** If the BD number typed already belongs to a saved customer, the saved name is used. If the typed name is different, the form shows once: "BD NUMBER is saved as NAME. The saved name will be used. To change a name, edit the customer."
- A new BD number creates a new customer when the order is saved (as in Loop 1).
- The phone typed on an order for an existing customer updates the saved phone only if the saved phone is blank.

## 8. Data notes

- **Customer:** BD number (unique among Officers), name, phone. Orders count, Spent and Due are calculated from orders each time, never typed and never stored separately.
- Officer and Airman customers are separate, even if the same BD number exists in both.

## 9. User flows

**A. Look up a customer.** Customers → search → tap History → see every order, what they paid and what is still due.

**B. Who owes me?** Customers → sort by Most due first → the top cards owe the most.

**C. Add a customer before an order.** Customers → Add Customer → BD number, name, phone → Save → later the name appears while typing a new order.

**D. Fast order for a returning customer.** New Order → type the first letters of the name → tap the suggestion → name, BD and phone fill in → carry on.

**E. Fix a spelling mistake.** Customers → Edit → correct the name → Save → their old orders show the correct name.

**F. Delete a customer with orders.** Tap Delete → blocked with the message → delete the orders first (Loop 1) → try again → confirm.

## 10. Not in this loop (do not build)

Airman customers, Export, merging customers, changing a BD number, customer notes, Airman orders, Dashboard, Bangla, dark mode, install as an app, login, Branch, staff pages, notifications.

## 11. Choices I made, to confirm

1. The BD number cannot be edited. A wrong BD number means adding a new customer and fixing orders by hand.
2. Editing a name or phone updates all the customer’s existing orders.
3. Customers with orders cannot be deleted.
4. Spent counts the total after discount, including orders that are not delivered yet.
5. Customer Due counts every order, not only delivered ones.
6. Customers and Customer History are two screens as in the PRD. If they feel the same in use, they can be merged later.

## 12. Done checklist (test in this order)

1. Customers lists everyone created from orders, with correct Orders, Spent and Due.
2. Search finds by name, by phone and by BD number. Each sort option reorders the list.
3. Add Customer with a new BD number: the card appears with Orders 0, Spent ৳0, Due ৳0.
4. Add Customer with an existing BD number: refused with the message.
5. Edit a customer’s name: the old orders show the new name; the BD number cannot be edited.
6. Delete a customer with orders: blocked. Delete one without orders: asks once, then removes.
7. Customer History lists all customers. Tap one: all their orders show with status, Total and Due. Tap an order: Order Details opens.
8. New Order: type part of a saved name. Suggestions appear. Tap one: name, BD number and phone fill in.
9. Type a saved BD number with a different name: the message appears once and the saved name is used on save.
10. Pay an order (Loop 2): that customer’s Due drops.
11. Open the app on a second device: the same customers appear.
12. No Export button exists. The word "optional" appears nowhere.
