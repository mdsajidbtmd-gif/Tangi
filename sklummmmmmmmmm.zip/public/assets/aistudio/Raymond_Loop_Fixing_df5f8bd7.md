# Raymond — Loop Fixing (Fix Pack V1)

Version 1.1 · Audience: AI builder · Owner: shop owner · Applies to: the app already built from the PRD (MVP) and Loops 1–2

## 0. How to read this document

- The owner recorded a reference app (tailorpro.pro.bd) to show **how each fix should behave**. Copy the behaviour only. Keep Raymond's own design language (DESIGN-orange.md, existing screens). Do not copy the reference app's menu, theme, typography or layout.
- Every fix has: what is wrong now, the required behaviour, rules, and a Done-when line. Section 6 is the combined acceptance checklist.
- Where this document and the PRD disagree, **this document wins** (see section 1).
- If something is unclear, ask the owner. Do not invent. Items still waiting for an owner answer are in section 5, each with the default to use until the owner answers.
- The word “optional” must still appear nowhere in the UI. Use blank-friendly fields and no label.

## 1. PRD changes (these override the PRD)

| Topic | PRD said | Now |
|---|---|---|
| Branch | Non-goal, no Branch field | **Branch dropdown on Officer orders only** (GDP, NON-GDP, HALF WING). Not on Airman orders. |
| Ribbon values | 0, 3, 4, 6 | **1 to 20**, default list, still editable in Settings. |
| Staff pages, khoroch | Non-goal | **In scope:** Staff Management, Staff Summary, worker prices, khorach column. |
| Export buttons | None anywhere | **Allowed only** on the staff pages (CSV, PDF) and in Settings → Data & Backup (admin downloads all data). Nowhere else. |
| Order delete | Permanent, no undo | Deleted orders go to **Deleted History** in Settings and can be restored (FIX-07). |
| Airman items | Same catalogue as Officer | Airman orders have **their own list of 6 items**, editable in Settings. |
| Item quantity | Typed with keyboard | **Dropdown, 1 to 10.** |
| Adding items | Pick item, pick quantity, press Add Item | **Row #1 is pre-loaded**; Add Item adds another row (FIX-03). |
| Acceptance lines “No Branch field, Export button, staff pages…” | Required | Superseded by this table. |

Everything else in the PRD stays as written (money rules, order numbers, Pay, drafts, statuses, printing).

## 2. Fix index and build order

Build in this order. Each pack can be tested before the next starts.

| Pack | Fix | Title |
|---|---|---|
| A. Foundation | FIX-01 | Numeric keypad that stays numeric |
| A | FIX-02 | BD number identity, suggestions, previous measurements |
| B. Order forms | FIX-03 | Item rows with dropdown quantity and live price |
| B | FIX-04 | Branch and Ribbon dropdowns |
| B | FIX-05 | Airman item list (6 items) |
| B | FIX-06 | Running Year dropdown and Add Year |
| C. Safety | FIX-07 | Deleted History and restore |
| C | FIX-08 | Unsaved-changes warning |
| C | FIX-09 | Backup, restore and data download |
| D. Staff | FIX-10 | Worker Items in Settings |
| D | FIX-11 | Workers list and month folders |
| D | FIX-12 | Month entry table |
| D | FIX-13 | Staff Summary upgrade |
| D | FIX-14 | Payslip and khorach history |
| E. Insight | FIX-15 | Dashboard upgrade |
| E | FIX-16 | Settings layout (collects all settings) |
| F. Branding | FIX-17 | Raymond name, logo, favicon and app icons |

Dependency: FIX-10 before FIX-12. FIX-16 is the home for the settings created by FIX-04, 05, 06, 07, 09, 10. FIX-17 (Pack F: the Raymond name, logo, favicon and app icons) is independent of the others; do it last, but before release.

## 3. Fix details

### FIX-01 — Numeric keypad that stays numeric

**Now:** In BD Number (Officer and Airman) and IV-Number (Airman), the phone keyboard switches back to letters after one digit, so numbers cannot be typed in one go.

**Required:**

- BD Number, IV-Number and Phone open the **numeric keypad** and keep it for the whole entry. Use a text input with numeric input mode and a digits-only pattern (not a spinner-style number input), and strip any non-digit characters on input.
- The keypad must not change between keystrokes. Likely cause to check: the input is re-created (remounted) on every keystroke, for example a component defined inside another component's render, a changing key, or a switch of the input type. Fix the cause; do not work around it.
- Customer Name stays a normal text field.
- Same behaviour on Officer form, Airman form, Add Customer and every search box that searches by number.

**Done when:** typing 10380 on a real phone needs no keyboard change and the cursor never loses focus mid-typing.

### FIX-02 — BD number identity, suggestions, previous measurements

The **BD number is the person.** It can never repeat inside a category. Names can repeat (two different people can share a name), so a name alone must never identify someone.

**Required:**

1. **Typing a BD number** opens a suggestion list under the field. Each suggestion shows BD number, saved name, and last order date. Matching is within the same category (Officer or Airman).
2. **Tapping a suggestion** fills BD number, name, phone **and loads that person's measurements from their most recent order** (all shirt and pant measurement values). Hand Written Notes and Extra Notes are not copied, because they belong to one order. Show a small line: “Measurements loaded from order #N · Clear”. All fields stay editable. Saving creates a new measurement set on the new order only and never changes the old order.
3. **Typing a complete existing BD number** without tapping a suggestion still fills the saved name and phone (PRD rule) and shows a one-tap strip “Use measurements from order #N”.
4. **Typing a name** shows suggestions that include the BD number beside each name, so two people with the same name can be told apart. Tapping fills name and BD number (and measurements, as in point 2).
5. A customer with no earlier order gets no measurement offer.
6. **Add Customer** and order save reject a BD number that already exists in that category with a clear message and a link to the existing customer.
7. If the typed name differs from the saved name for an existing BD number, the saved name wins (PRD assumption stays).

**Done when:** entering a known BD number and tapping the suggestion fills the form including measurements in one tap.

### FIX-03 — Item rows with dropdown quantity and live price

**Now:** Pick item, type quantity, press Add Item. **Same problem on Officer and Airman forms.**

**Required (Officer form):**

- The Items area opens with **row #1 already present and already selected** (the first item of the item list, quantity 1, price showing).
- Each row: **searchable item dropdown** (a Search items box at the top of the open list, and a **Manage Items** link at the bottom that opens Settings), **quantity dropdown 1 to 10**, the **row price shown live** (price × quantity, updating as soon as item or quantity changes), and a **red delete icon** on every row when there are two or more rows.
- **Add Item** adds the next row below (same defaults). Third item: press Add Item again. No limit on rows.
- Total Amount, Due and the rest update instantly as rows change.
- Selecting an item never needs typing; typing is only for searching.

**Required (Airman form):** the same rows, with an **IV-Number** field before the item dropdown, and no price shown. Rules from the PRD stay: IV-Number required on each row; one IV-Number belongs to one person; the same person can repeat it across rows.

**Phone layout:** a row may wrap to two lines, but the item, quantity and delete controls must stay thumb-sized.

**Done when:** a new order can be completed with three items using only taps, no keyboard for items or quantity.

### FIX-04 — Branch and Ribbon dropdowns

- **Branch (Officer orders only):** a dropdown with the placeholder “Select Branch” and three values: **GDP, NON-GDP, HALF WING**. Not required to save. Not on Airman orders. The Branch list lives in Settings → Lists with these three as defaults.
- **Ribbon (Officer and Airman):** a dropdown with the placeholder “Select Ribbon” and values **1 to 20**, scrollable. The list lives in Settings → Lists with 1–20 as defaults, editable (PRD). Replaces the old 0, 3, 4, 6 start values.
- Both are chosen from the list, never typed. Show Branch on the order card details and the order details page. Printing Branch: see section 5.

### FIX-05 — Airman item list (6 items)

- Airman orders use their own list. Starter list, exact spelling: **Battle Uniform, Half Sleeve, Full Sleeve, Summer Ceremonial, Winter Ceremonial, MODC Uniform.**
- The Airman item dropdown shows only these (plus anything the owner adds later).
- Settings → **Airman Items**: add, rename, remove. Changing the list never changes saved orders.
- The Airman page summary cards use these names. Because the names now match exactly, the old mapping “Half Sleeve Shirt counts under Half Sleeve” is no longer needed for Airman orders.
- Everything in FIX-03 applies here too (rows, quantity dropdown, delete icon).

### FIX-06 — Running Year dropdown and Add Year

**Now:** only 2026–2027 exists and no other year can be added.

**Required:**

- Running Year is a **dropdown of years** shown as rows. Starter list: **2025–2026, 2026–2027, 2027–2028, 2028–2029, 2029–2030**, with 2026–2027 selected by default. The list can hold more.
- **Add Year** opens a small inline “New Year” field with **Save** and **Cancel** (as in the reference). The new year appears in the dropdown at once, in order, and is selected.
- Format is two consecutive years, for example 2030–2031. Reject duplicates and wrong formats with a clear message.
- The same list feeds the Airman page “All Years” filter and Settings → Lists → Running Years.

### FIX-07 — Deleted History and restore

Settings gets a **Deleted Orders** page. It replaces “permanent delete, no undo”.

**Deleting** (two-step confirmation stays): the order leaves Orders and goes to Deleted History **with the order number it had**. Later orders in that category move down by one (PRD).

**Deleted History page:** tabs Officer and Airman, search (order number, BD number, name), newest deletion first. Each entry: category badge, original order number, customer name and BD number, total (Officer), status when deleted, deleted date and time, and a **Restore** button.

**Restore rule:** the order returns with its **original number N**. Every current order in that category with a number **N or higher moves up by one**. If N is higher than the current highest number plus one, it takes the next free number instead. Everything comes back as it was: items, measurements, notes, dates, status, delivered date, payment records.

Worked example: orders 521–525. Delete #523 → old 524 becomes 523 and old 525 becomes 524. Restore → the restored order is #523 again, the current 523 becomes 524, the current 524 becomes 525.

- Restoring asks one confirmation that says the numbers below will change.
- Dashboard, customer Orders / Spent / Due and Upcoming cards recalculate after delete and after restore.
- Several deletions are fine: each entry keeps its own number from the moment it was deleted.
- No automatic cleanup. Drafts are not part of this history.

### FIX-08 — Unsaved-changes warning

- When a form has unsaved changes and the user leaves (Cancel, back arrow, sidebar menu, browser back, closing the tab), show a dialog: **Stay**, **Leave without saving**, and **Save as Draft** (when the draft rules are met).
- Applies to Officer and Airman order forms, Add/Edit Customer, the month entry table (FIX-12) and Settings editors.
- It never appears when nothing changed. The existing “Draft saved locally” and “Unsaved changes / Update Order” behaviour stays.

### FIX-09 — Backup, restore and data download

Settings → **Data & Backup**:

- **Download backup:** one file with everything (orders, Deleted History, drafts, customers, payments, staff data, all settings). Show the date of the last backup.
- **Restore from backup:** choose a file, validate it, show what it contains (counts and backup date), then ask a two-step confirmation that says all current data will be replaced. Automatically download a safety copy of the current data first.
- **Download all data (admin):** CSV files of every table in one download. This is the only place the whole dataset can be exported.
- Staff pages keep their own CSV and PDF buttons (FIX-12, FIX-13).

### FIX-10 — Worker Items in Settings

- Settings → **Worker Items**: a list with item name and **worker price** (taka), search, **Add Worker Item**, edit, delete. Starter data: section 4.3.
- Worker price is **separate from the order price** (for example order price ৳500 versus worker price ৳100). It is only used to calculate what a worker is paid.
- A price copied into a saved staff entry never changes when the worker price is edited later (same principle as order prices).
- Every item dropdown on the staff screens has a **Manage Items** link at the bottom that opens this page.

### FIX-11 — Workers list and month folders

**Workers page** (sidebar: Staff Management): title “Workers”, subtitle, language switch, **Add** button. A “Workers List” card with a count pill, a search box, and numbered rows. Each row: name with the Bangla name beside it, expand arrow, edit icon, delete icon. Add/Edit worker fields: English name, Bangla name. Delete asks a two-step confirmation.

**Month folders:** tapping a worker expands the row into **Month-wise work entries**:

- A **year switcher** (previous / next arrow around the year, for example 2027). Default is the current year.
- **12 month folders**, three per row on desktop and two on phone. Every month has its **own strong colour and its own symbol** (table 4.5), so a month is recognised at a glance without reading. The month name is always written too, so colour is never the only clue.
- Each folder also shows a small count of entries and total taka for that worker and year.
- Tapping a folder opens that month's entry screen (FIX-12).

**The month screen takes the month's colour:** a header band in the month colour with the symbol, worker name and “Month Year”, a softly tinted page background, month-coloured table header, buttons focus rings and highlights. The user must always know which month they are adding work to. In dark mode use a darker tint of the same colour.

### FIX-12 — Month entry table

Opening a month shows the saved entries for that worker, month and year, followed by **10 blank rows**. Top bar: back arrow, worker name (and Bangla name), language switch, search by name or item, **Recalculate**, **CSV**, **PDF**. Card “Entry List” with **Add 10 Rows** and **Save**.

Columns, in this order: **Date, Serial, Name, Item, Quantity, Unit Price, Total Taka, Khorach Date, Khorach, Total Payable**, then a delete icon.

- **Item:** searchable dropdown of Worker Items with their prices, and Manage Items at the bottom. Picking an item fills **Unit Price** from the worker price. Unit Price stays editable.
- **Quantity:** number, default 1.
- **Total Taka** = Quantity × Unit Price.
- **Khorach Date, Khorach:** the date and taka amount given to the worker. Date picker starts blank (“Pick date”).
- **Total Payable** (per row) = Total Taka − Khorach.
- **Footer:** Total (taka), Total Khorach, Total Payable for the visible month.
- **Date** defaults to the first day of the selected month (or today when inside the current month). Serial and Name are free text.
- Rows with no item are ignored on Save. **Recalculate** recomputes every row and the footer.
- On a phone the table must stay fully usable (horizontal scroll with a fixed first column, or stacked row cards). **Add 10 Rows** always appends 10 more.
- The unsaved-changes warning (FIX-08) applies.

### FIX-13 — Staff Summary upgrade

Keep what the reference shows: title “Staff Summary” with subtitle, **Recalculate Totals**, six cards (**Total Staff, Total Amount, Total Khorach, Total Payable, Total Received, Total Due**), a search by staff name, a month/year filter, a status filter (All Status), and a table with a loading state.

Table columns: #, Staff Name (with Bangla name), Total Amount, Khorach, Net Payable, Received, Due, Status. (The recording cuts off after Net Payable; Received, Due and Status follow the card names. See section 5.)

**Upgrades (owner approved):**

1. **Top Earners:** the top five workers for the selected period, shown as ranked cards in distinct colours. Tapping one opens that worker.
2. **Month strip per worker:** twelve small squares in each worker row using the month colours and symbols from table 4.5, with stronger shade for higher earnings. Tapping a square opens that month's entry screen.
3. **Due by month:** a bar chart of what is still due, one bar per month in the month colours.
4. Cards and table respond to the selected month and year. CSV and PDF buttons export the visible table.

### FIX-14 — Payslip and khorach history

- On the month screen and in each Staff Summary row: **Print Payslip** for one worker and one month. A4 by default (Settings print size). Shows shop name and logo from the invoice template, worker name (English and Bangla), month and year, the entries table, Total Taka, Total Khorach and Total Payable.
- On the month screen: a collapsible **Khorach history** list of rows where Khorach is above 0, sorted by date, with a running total.

### FIX-15 — Dashboard upgrade

Keep every existing block (Today, This Week, This Month, All Time; quick numbers; monthly bar chart; status donut; recent orders). Add:

- A **period picker** (Today, This Week, This Month, All Time, or a chosen month and year) and a **metric switch** for the charts (Orders, Sales, Collection, Due). Tapping any number still shows the details behind it.
- An **Airman block:** total quantity per item for the chosen Running Year (no money).
- **Branch split** for Officer orders (GDP, NON-GDP, HALF WING) as a donut or bars.
- An **Overdue deliveries** card: not Delivered and delivery date earlier than today. Tapping it filters the Orders list.
- Dashboard money still covers Officer orders only. Deleted orders are excluded; restored orders come back in.

### FIX-16 — Settings layout

Settings sections, in this order: Items & Prices (Officer items, with a category field so the item dropdown can group by category), Airman Items, Worker Items, Default discount type, Upcoming delivery days, Invoice template, Print paper size, Lists (Ribbon, Branch, Trade, Office, Running Years), Deleted Orders, Data & Backup, Install app.

### FIX-17 — Raymond name, logo, favicon and app icons

**The app is now called Raymond.** It is not Darzi, not Darji and not Buff Tailors. This overrides the app name used in the PRD and the Loop documents.

**Name — change it everywhere:**

- Visible text: sidebar and header brand, browser tab titles (format “Page · Raymond”), loading and splash screens, install prompts, Settings → Install app text and QR page, empty states, dialogs, both English and Bangla.
- Technical: PWA manifest name and short_name (both “Raymond”), the apple-mobile-web-app-title and page meta tags, package name and README, and the file names of downloads (for example raymond-backup-YYYY-MM-DD, raymond CSV exports, payslip PDFs).
- Search the whole project, code and assets, for Darzi, Darji and Buff Tailors in every spelling and case, and replace them. Leave none behind.
- The shop name on the invoice comes from the Settings invoice template and belongs to the owner. Do not change it.

**Logo — the owner supplies it.** The owner will give the logo files and a localhost link from Claude. Implement **exactly that logo**: do not redraw it, recolour it, simplify it, crop it, or retype its wordmark as text. Prefer the vector (SVG) and export PNG sizes from it. If the link cannot be reached, or the logo is unclear, ask the owner. Do not substitute a placeholder.

**Use the exact logo in all three places:**

1. **Favicon (website and browser tab):** favicon.ico (16, 32, 48 px), favicon.svg, PNG 16 and 32 px, and an apple-touch-icon of 180 × 180 px, all linked in the page head. It must be readable on light and dark browser tabs.
2. **App icon (installed PWA on the phone or computer home screen):** manifest icons at 192 × 192 and 512 × 512 px, plus a maskable 512 × 512 px version with the logo kept inside the safe zone (about the central 80%) so no edge is cut. Give the icon a solid background colour taken from the logo, never a transparent or black one. Set the manifest theme and background colours to match.
3. **Inside the app:** the brand mark at the top of the sidebar or header (expanded and collapsed), and on the loading or splash screen. If the logo does not show well on dark mode, use a dark-mode version supplied by the owner, or place it on a neutral chip. Never change the logo's own colours. Invoices and cutting slips keep the logo uploaded in Settings → Invoice template.

**Done when:**

- The browser tab shows the exact logo as its favicon.
- The app installed on a phone shows the exact logo as its home screen icon, uncropped, with the name “Raymond” under it.
- The sidebar and the loading screen show the exact logo.
- A project-wide search finds no Darzi, Darji or Buff Tailors.
- The manifest name is “Raymond” and the app passes the browser's installability check.

## 4. Starter data

### 4.1 Branch

GDP · NON-GDP · HALF WING

### 4.2 Ribbon

1, 2, 3, … 20 (every whole number from 1 to 20)

### 4.3 Worker items and worker prices (৳)

Read from the owner's screen recording, which is low resolution. Keep the spelling exactly as shown, including odd spellings. Every price is editable in Settings. Flagged rows must be shown to the owner for checking.

| # | Item | ৳ | # | Item | ৳ | # | Item | ৳ |
|---|---|---|---|---|---|---|---|---|
| 1 | H/S Officer | 105 | 2 | H/S Airman | 100 | 3 | F/S Officer | 105 |
| 4 | F/S Airman | 100 | 5 | N.B Officer | 95 | 6 | N.B Airman | 75 |
| 7 | Battle Shirt Airman | 155 | 8 | Battle Shirt Officer | 160 | 9 | Battle Pant Airman | 155 |
| 10 | Battle Pant Officer | 160 | 11 | Summer Ceremonial Officer | 500 | 12 | Summer Ceremonial Airman | 305 |
| 13 | Winter Ceremonial Officer | 400 | 14 | Winter Ceremonial Airman | 400 | 15 | Meskit Officer | 750 |
| 16 | MODC Shirt Officer | 85 | 17 | MODC Pant | 80 | 18 | Summer Ceremonial Pant | 100 |
| 19 | Meskit Pant | 105 | 20 | Meskit Shirt | 205 | 21 | Mission Ganji | 115 |
| 22 | Civil Shirt | 140 | 23 | Civil Pant | 200 | 24 | Civil Court | 800 |
| 25 | Civil Safari | 350 | 26 | Punjabi | 150 | 27 | Paijama | 100 |
| 28 | Ladies Shirt Officer | 165 | 29 | Ladies Shirt Airman | 145 | 30 | Maintenance Coverall | 455 |
| 31 | safari pant | 110 | 32 | BAND DRESS PANT | 90 | 33 | BAND DRESS | 600 (check, one frame looked like 800) |
| 34 | half buss | 370 | 35 | KOTI | 500 (check) | 36 | CIVILIAN SAFARI | 180 |
| 37 | AFOLET | 60 | 38 | Night drees | 250 | 39 | KHORUS | 0 |
| 40 | GENZI MISUN | 115 | 41 | CEF | 25 | 42 | FAEAR | 155 |
| 43 | HACAR | 300 | 44 | BIRD SHOOTER | 85 | 45 | MODC KHAKI SHIRT | 100 |
| 46 | MODC HALF PANT | 35 | 47 | AIRMAN S/C PANT | 85 | 48 | AFRUN | 100 (check) |
| 49 | AFRUN | 10 (check, same name as 48) | 50 | KOK SART | 85 | 51 | KOK FAYZAMA | 50 |

Note: “KHORUS” has price 0 in the recording; keep 0 until the owner changes it. The recording also shows 39 workers on the Staff Summary; the first names legible are Wasim, Sayed, Sentu, Kanchan, Jewel, Rana, Qader, Yunus, Rabiul Short, Alhaj, Zobayer, Chana + Salam, Mintu, Asadul Rangpur, Shimul, Kabir, Saiful, Farid, monir, SAPON, SHAHJAHAN. Do not seed workers; the owner adds them with Add.

### 4.4 Airman items and running years

See FIX-05 and FIX-06.

### 4.5 Month colours and symbols

Symbols are Lucide icon names. Strong colour is used for the folder icon, header band and accents. Tint = the strong colour at about 12% on a light surface (about 20% on dark). Put dark ink text on tints; do not put small white text on Lime or Amber. Check that neighbouring months are easy to tell apart.

| Month | Symbol | Colour | Strong |
|---|---|---|---|
| January | snowflake | Blue | #2563EB |
| February | heart | Pink | #DB2777 |
| March | sprout | Green | #16A34A |
| April | cloud-rain | Teal | #0D9488 |
| May | flower | Magenta | #C026D3 |
| June | sun | Amber | #D97706 |
| July | cloud-lightning | Violet | #7C3AED |
| August | umbrella | Sky | #0284C7 |
| September | wheat | Lime | #65A30D |
| October | moon | Indigo | #4338CA |
| November | wind | Slate | #475569 |
| December | gift | Red | #DC2626 |

## 5. Open decisions (use the default until the owner answers)

1. **Airman item prices:** Airman orders show no prices (PRD). Default: Airman Items in Settings have a name only, no price field.
2. **Airman summary cards:** Default: one card per item in the Airman item list, so added items also get a card.
3. **Branch on printouts:** Default: Branch shows on order card details and order details only, not on invoice or cutting slip, until confirmed.
4. **Staff money meaning:** Default: Net Payable = Total Amount − Khorach; Received = payments marked as paid to the worker; Due = Net Payable − Received. Confirm how “Received” is recorded.
5. **Quantity above 10:** Default: dropdown stops at 10, as requested. Ask the owner if bigger quantities are ever needed.
6. **Dashboard selector:** the owner said the dashboard should let him select things (period, totals, parameters). Default: the period picker and metric switch in FIX-15. Confirm.
7. **Permanent purge of Deleted History:** Default: no purge in this release.
8. **Deleting a worker:** Default: blocked while the worker has saved entries.
9. **Serial and Name columns** on the month table: meaning not explained. Default: free text.
10. **Worker price list:** rows flagged “check” in 4.3 need the owner to confirm.

## 6. Acceptance checklist

- BD Number, IV-Number and Phone keep the numeric keypad for the whole entry on a real phone.
- Typing a BD number shows suggestions; tapping one fills name, phone and the person's latest measurements (not the notes).
- Two customers with the same name can be told apart by BD number in suggestions. A duplicate BD number in the same category is rejected.
- A new Officer or Airman order opens with item row #1 already selected; Add Item adds row #2, #3 and so on; every row has a quantity dropdown 1–10 and (with 2+ rows) a delete icon.
- Officer rows show a live price; Airman rows show none and have an IV-Number.
- Item dropdowns have a search box and a Manage Items link.
- Branch (Officer only) lists GDP, NON-GDP, HALF WING. Ribbon lists 1–20 on both forms.
- Airman orders offer only the 6 Airman items; the list is editable in Settings.
- Running Year shows several years, and Add Year adds a new one with Save and Cancel.
- Deleting order #N moves later orders down; the order appears in Deleted History; Restore brings it back as #N and moves later orders up.
- Leaving a changed form shows Stay / Leave without saving / Save as Draft.
- A backup file downloads and restores correctly, after a safety copy and a two-step confirmation.
- Worker Items in Settings hold the 51 starter items; editing a price does not change saved entries.
- Each worker expands into 12 month folders with distinct colours and symbols and a year switcher; opening a month tints the whole screen in that colour.
- The month table has the ten columns in order, 10 blank rows, Add 10 Rows, Save, Recalculate, CSV, PDF and a correct footer.
- Staff Summary shows six cards, Top Earners, the month strip and the due-by-month chart.
- Payslip prints for one worker and one month.
- Dashboard has the period picker, metric switch, Airman block, Branch split and Overdue deliveries.
- Export appears only on the staff pages and in Settings → Data & Backup.
- The word “optional” appears nowhere in the UI.
