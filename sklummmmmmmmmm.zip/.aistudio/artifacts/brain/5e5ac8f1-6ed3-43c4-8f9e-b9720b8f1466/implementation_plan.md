# Raymond Tailor Shop Manager — Complete UI/UX Overhaul & Brand Unification

Transform Raymond into a cohesive, high-contrast, professional tailor shop management application. This plan eliminates disconnected color palettes, removes extraneous consumer greetings and the misplaced "Due after delivery" section, fixes top-bar logo duplication, and provides a fully responsive mobile-first and desktop-optimized layout adhering to our Polaris-inspired design system.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Summary of confirmed design decisions from user feedback:**
> - **Visual Brand Language**: Strict adherence to the Polaris workbench tokens (`#1A1A1A` chrome, `#EBEBEB` sidebar, `#F1F1F1` canvas, `#FFFFFF` cards, `#303030` primary action buttons). No glowing neon gradients or arbitrary royal blue buttons.
> - **Desktop & Mobile Navigation**: Desktop utilizes a fixed 240px sidebar with unified branding; mobile features a clean top bar with hamburger menu drawer plus quick mobile bottom actions. Single brand lockup on the top bar (no redundant store avatar duplication).
> - **Dashboard Focus**: Remove the arbitrary "Good morning" consumer greeting and eliminate the intrusive "Due after delivery" hero block. Focus the dashboard on active workshop pipeline, urgent cutting slips, upcoming delivery deadlines, and daily workshop operations.
> - **Mobile Responsiveness**: Replace cramped and overflowing desktop table rows on mobile with thumb-friendly responsive order cards (drawing inspiration from the Invoices and Shipping tracker mobile designs) while preserving the high-density table view on desktop screens.
> - **Creative Distinction**: Bespoke SVG tailoring illustrations (measuring tape, cutting shears, uniform silhouettes), tasteful micro-animations (Framer Motion transitions), and clear visual contrast without AI slop.

---

## 1. Overview & Core Concept

- **What It Does**: Raymond is a specialized operational workbench for Bangladesh Air Force (BAF) Officer and Airman uniform tailoring. It handles customer measurements, cutting slip generation, status progression (Pending → Cutting Slip – Done → Delivered), payment recording, and staff piece-rate accounts.
- **Target Audience / Persona**: Tailor shop owners, cutting masters, and desk managers who need rapid order lookup, clear order statuses, precise delivery scheduling, and error-free receipts.
- **Key Value**: Replaces paper logbooks and fragmented spreadsheets with a fast, calm, error-resilient operational tool that works equally well on mobile phones at the counter and desktop screens at the cutting desk.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Dashboard & Workshop Pulse**:
   - Clean top operational stats (Active Orders, Cutting Slips Needed, Deliveries Next 3 Days, Total Receivables).
   - Workshop Queue: Immediate view of orders requiring attention (due today or tomorrow, cutting slips in progress).
   - Quick action: "+ New Order" and "Delivery Queue" in brand near-black.
2. **Order Management (Officer & Airman)**:
   - **Desktop**: 54px dense table with hairline dividers, tabular numerals, status pills (Active `#AFFEBF`, Pending `#E3E3E3`, Attention `#FEE9E8`), and row click expansion.
   - **Mobile**: Responsive card view where each order is rendered as an ergonomic touch card displaying Order #, Officer Rank/BD No, delivery countdown, amount/due breakdown, and tap-to-action buttons.
3. **Order Creation & Cutting Slip**:
   - Two-column structured form with smart defaults, customer auto-complete, item checkboxes, and automatic due calculation.
   - Clean print preview for physical workshop cutting slips and customer invoices.

### Visual Identity & Theme

- **Aesthetic Direction**: Operational commerce workbench—calm, confident, tactile, high-contrast, and utilitarian.
- **Surface Layer Stack**:
  - `Layer 0 (Chrome)`: `#1A1A1A` (Top bar, near-black with crisp white type).
  - `Layer 1 (Rail / Sidebar)`: `#EBEBEB` (Light gray sidebar, active item `#FAFAFA` with subtle elevation).
  - `Layer 2 (Canvas)`: `#F1F1F1` (Neutral canvas background).
  - `Layer 3 (Card)`: `#FFFFFF` with 1px `#E3E3E3` border and 12px radius (`rounded-xl`).
- **Typography**:
  - `Inter` display and body pairing with `tabular-nums` for all monetary amounts (৳) and BD numbers.
  - Page Title: 20px / 28px (Font weight 650).
  - Card Headings: 14px / 20px (Font weight 650).
  - Body & Table: 13px / 20px (Font weight 450).
  - Metadata & Tags: 12px / 16px (Font weight 500).
- **Brand & Action Buttons**:
  - Primary CTA: Near-black `#303030` (`hover:bg-[#1A1A1A]`, text `#FFFFFF`, border `#1A1A1A`, 8px radius). **No random blue CTAs.**
  - Secondary Actions: Clean white `#FFFFFF` with 1px border `#E3E3E3` (or `#E3E3E3` on canvas).
  - Destructive Actions: Contained within two-step confirmation modals.
- **Top Bar Contract**:
  - Left: Single crisp Raymond scissors brand mark + title ("Raymond").
  - Center: Centered global search with `⌘K` shortcut trigger.
  - Right: Notification bell with red badge + Quick Settings gear icon. (Removed redundant duplicate logo avatar).

### Bespoke Illustrations & Motion

- **Handcrafted Tailoring SVG Illustrations**:
  - Empty state illustrations featuring geometric sewing shears, measuring tape, and pattern paper.
  - Status progression icons with subtle tactile feedback.
- **Motion Budget**:
  - Page entry fade-in: 150ms ease-out (`transform`, `opacity` only).
  - Modal scrim & bottom drawer transitions: 200ms cubic-bezier curve.
  - Zero layout shift during data mutations.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Removal of "Due After Delivery" Hero & Greeting Banner**:
  - *Chosen Approach*: Eliminate the glowing neon hero box and the "Good morning" greeting on the dashboard. Replace with an actionable 4-stat operational bar (Active Orders, Cutting In Progress, Approaching Delivery, Outstanding Due).
  - *Why*: The previous hero card dominated the viewport with non-standard dark gradients and confusing motives. Tailor shop staff need instant awareness of physical jobs in queue rather than greeting text.
  - *Alternatives Considered*: Moving receivables to a secondary accordion. Rejected in favor of a clean KPI metric card that is calm and readable.
- **Decision 2: Mobile Dual-View (Card Feed on Mobile, Table on Desktop)**:
  - *Chosen Approach*: On screens `< 768px`, automatically render orders as structured touch-friendly cards with high thumb tap-targets ($\ge 44\text{px}$). On screens `\ge 768px`, render the Polaris 54px dense table.
  - *Why*: Data tables with 8+ columns inevitably collapse or horizontally clip on phones. Cards provide immediate visibility into rank, BD number, items, and status without awkward horizontal scrolling.
- **Decision 3: Single Brand Header & Mobile Hamburger Drawer**:
  - *Chosen Approach*: Retain the desktop sidebar for `\ge 1024px`. On `< 1024px`, provide a slide-over mobile drawer triggered by the top-bar hamburger, complemented by a persistent bottom action bar for primary screens.
  - *Why*: Resolves the user's issue with duplicate logos in the top bar and provides true mobile responsiveness.

---

## 4. Technical Architecture & Component Structure

```
┌────────────────────────────────────────────────────────────────────────┐
│                        TopBar (56px, #1A1A1A)                          │
│  [Scissors + Raymond]          [Centered Search ⌘K]        [Bell] [⚙]  │
└────────────────────────────────────────────────────────────────────────┘
┌───────────────────────┬────────────────────────────────────────────────┐
│  Sidebar (240px)      │  Main Canvas (#F1F1F1, p-6, rounded-tl-xl)     │
│  (#EBEBEB)            │                                                │
│  • Orders (Active)    │  [PageHeader: Title + Actions (#303030)]       │
│  • Airman Orders      │  ┌──────────────────────────────────────────┐  │
│  • Delivery Queue     │  │  Operational Metric Card (4-Col Grid)    │  │
│  • Drafts             │  └──────────────────────────────────────────┘  │
│  • Customers          │  ┌──────────────────────────────────────────┐  │
│  • Staff Hishab       │  │  Saved View Tabs: [All] [Pending] [...]  │  │
│  • Dashboard          │  │  --------------------------------------- │  │
│  ───────────────────  │  │  Orders: Table (Desktop) / Cards (Mobile)│  │
│  ⚙ Settings (Pinned)  │  └──────────────────────────────────────────┘  │
└───────────────────────┴────────────────────────────────────────────────┘
```

### Key Components to Refactor

1. **`src/components/polaris/TopBar.tsx`**:
   - Remove redundant store avatar on the right (eliminates the double logo issue).
   - Ensure clean 3-zone structure with centered search.
2. **`src/components/DashboardScreen.tsx`**:
   - Strip the consumer "Good morning" header.
   - Replace the dark neon "Due after delivery" container with a Polaris 4-column metric card and daily workshop dispatch schedule.
   - Fix all CTA buttons from bright blue (`#005BD3`) to brand near-black (`#303030`).
3. **`src/components/OfficerOrdersScreen.tsx` & `AirmanOrdersScreen.tsx`**:
   - Remove the standalone "Due after delivery" card that distracted from the table.
   - Implement responsive mobile order cards with clear status pills and payment action sheets.
   - Standardize all action buttons to the Polaris button tokens.
4. **`src/components/Illustrations.tsx`**:
   - Create tailored SVG illustrations for empty states, pending cutting slips, and successful delivery.
5. **`src/design/tokens.css` & Global Styles**:
   - Enforce uniform tokens across all modals, dialogs, forms, and badges.

---

### Verification & Testing Plan

1. **Visual Consistency Check**: Inspect every screen (Officer Orders, Airman Orders, Dashboard, Delivery, Customers, Staff) to ensure consistent `#1A1A1A` / `#303030` buttons, `#E3E3E3` borders, and unified typography.
2. **Mobile Responsiveness**: Test at 375px (iPhone), 414px, and 768px (iPad) viewports to verify that mobile cards render cleanly without overflow or clipped text, and the hamburger menu and bottom bar operate seamlessly.
3. **Interactive Handlers**: Verify all search, filter, status change, payment entry, cutting slip generation, and order edit handlers function smoothly.
4. **Build Verification**: Run `compile_applet` and `lint_applet` to guarantee error-free compilation.
