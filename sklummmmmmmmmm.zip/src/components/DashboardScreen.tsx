import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { formatDate } from '../utils/logic.ts';
import {
  Scissors,
  Truck,
  Plus,
  CreditCard,
  Printer,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Phone,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  Plane,
  ClipboardList,
  Sparkles,
  Check,
  PackageCheck,
  ShieldAlert,
  Folder as FolderIcon,
  Search,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { DramsSearch } from './elements/DramsSearch.tsx';
import { GlassyButton } from './elements/GlassyButton.tsx';
import { PulseButton } from './elements/PulseButton.tsx';
import { AvatarGroupEditable } from './elements/AvatarGroupEditable.tsx';
import { Folder } from './elements/Folder.tsx';
import { DashboardCharts } from './elements/DashboardCharts.tsx';
import { GeniestudioDivider } from './elements/GeniestudioDivider.tsx';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  return Math.round((dDate - tDate) / (1000 * 3600 * 24));
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, recordOfficerPayment } = useApp();

  const [activeQueueTab, setActiveQueueTab] = useState<'all' | 'cutting' | 'upcoming' | 'overdue' | 'delivered'>('all');
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string>('');

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Active orders in pipeline (Not yet delivered)
  const activeOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  const activeAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const totalActivePipeline = activeOfficerOrders.length + activeAirmanOrders.length;

  // Cutting slips needed (Pending orders awaiting cutting slip)
  const cuttingSlipNeededOfficer = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Pending');
  }, [state.officerOrders]);

  // Overdue orders
  const overdueOrders = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
      return diff !== null && diff < 0;
    });
  }, [state.officerOrders, todayStr]);

  // Upcoming deliveries (Next 3 days)
  const upcomingDeliveries = useMemo(() => {
    return state.officerOrders
      .filter((o) => {
        if (o.status === 'Delivered') return false;
        const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
        return diff !== null && diff >= 0 && diff <= upcomingDays;
      })
      .sort((a, b) => (a.deliveryDate || '').localeCompare(b.deliveryDate || ''));
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Recently delivered orders
  const recentlyDeliveredOrders = useMemo(() => {
    return state.officerOrders
      .filter((o) => o.status === 'Delivered')
      .slice(0, 10);
  }, [state.officerOrders]);

  // Total Outstanding Due across all orders
  const totalOutstandingDue = useMemo(() => {
    return state.officerOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [state.officerOrders]);

  const ordersWithDueCount = useMemo(() => {
    return state.officerOrders.filter((o) => (o.due || 0) > 0).length;
  }, [state.officerOrders]);

  // Quick Action: Mark Delivered
  const handleQuickDeliver = (orderNumber: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    updateOfficerOrderStatus(orderNumber, 'Delivered');
    setToastMessage(`✓ Order #${orderNumber} marked as Delivered! Cleared from cutting queue.`);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Quick Action: Mark Cutting Done
  const handleQuickMarkCut = (orderNumber: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    updateOfficerOrderStatus(orderNumber, 'Cutting Slip – Done');
    setToastMessage(`✂ Cutting slip marked done for Order #${orderNumber}!`);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Priority Workshop Queue
  const priorityQueue = useMemo(() => {
    let list: OfficerOrder[] = [];

    if (activeQueueTab === 'cutting') {
      list = cuttingSlipNeededOfficer;
    } else if (activeQueueTab === 'upcoming') {
      list = upcomingDeliveries;
    } else if (activeQueueTab === 'overdue') {
      list = overdueOrders;
    } else if (activeQueueTab === 'delivered') {
      list = recentlyDeliveredOrders;
    } else {
      // 'all': Combine overdue first, then upcoming, then pending cutting slips
      const seen = new Set<number>();
      const combined: OfficerOrder[] = [];

      overdueOrders.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      upcomingDeliveries.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      cuttingSlipNeededOfficer.forEach((o) => {
        if (!seen.has(o.orderNumber)) {
          seen.add(o.orderNumber);
          combined.push(o);
        }
      });

      list = combined;
    }

    return list;
  }, [activeQueueTab, cuttingSlipNeededOfficer, upcomingDeliveries, overdueOrders, recentlyDeliveredOrders]);

  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payTargetOrder) return;
    const amount = parseFloat(payAmountInput);
    if (isNaN(amount) || amount <= 0) return;

    recordOfficerPayment(payTargetOrder.orderNumber, amount);
    setToastMessage(`Payment of ৳${amount.toLocaleString('en-IN')} recorded for Order #${payTargetOrder.orderNumber}!`);
    setPayTargetOrder(null);
    setPayAmountInput('');
    setTimeout(() => setToastMessage(''), 3500);
  };

  return (
    <PolarisPage
      title="Workshop Dashboard"
      subtitle="Daylight tailoring operations, live orders velocity, and workshop staff management"
      primaryAction={{
        content: '+ New Officer Order',
        onAction: () => onNavigate('new-officer-order'),
      }}
      secondaryActions={[
        {
          content: '+ Airman Order',
          onAction: () => onNavigate('new-airman-order'),
        },
        {
          content: 'Delivery Log',
          onAction: () => onNavigate('delivery'),
        },
      ]}
    >
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-900 flex items-center justify-between shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="text-sm font-semibold">{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage('')}
            className="p-1 hover:bg-emerald-500/15 rounded-lg text-emerald-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Search Bar (DramsSearch component) */}
      <div className="mb-6">
        <DramsSearch
          variant="expanded"
          onNavigate={onNavigate}
          placeholder="Search Officer by rank, Airman trade, BD number, or tailor hishab..."
        />
      </div>

      {/* Workshop Executive Banner (Geniestudio Daylight styling) */}
      <div className="mb-8 rounded-[32px] bg-gradient-to-br from-[#ffffff] via-[#fafdff] to-[#ebf5ff] border border-white p-6 sm:p-8 shadow-[0_12px_36px_rgba(4,69,144,0.06)] relative overflow-hidden">
        {/* Soft atmospheric gradient accents */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-[#cce7ff]/40 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-[#f1e6ff]/40 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#ebf5ff] text-[#0069e0] text-xs font-semibold mb-3 border border-[#dbeafe]">
              <Scissors className="w-3.5 h-3.5" />
              <span>Bangladesh Air Force Outfitter Studio</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-medium text-[#0a0d12] tracking-tight">
              Raymond Tailor Workshop
            </h2>
            <p className="text-sm text-[#535862] mt-1.5 leading-relaxed">
              Active workshop queue has <strong className="text-[#0a0d12]">{totalActivePipeline} uniforms</strong> in production. Maintain strict BAF officer measurements, cutting slips, and on-time delivery schedule.
            </p>

            {/* Quick Action Buttons using GlassyButton & PulseButton */}
            <div className="flex flex-wrap items-center gap-3 mt-5">
              <GlassyButton
                variant="primary"
                icon={<Plus className="w-4 h-4" />}
                onClick={() => onNavigate('new-officer-order')}
              >
                New Officer Order
              </GlassyButton>

              <GlassyButton
                variant="subtle"
                icon={<Plane className="w-4 h-4 text-[#0069e0]" />}
                onClick={() => onNavigate('new-airman-order')}
              >
                New Airman Order
              </GlassyButton>

              {overdueOrders.length > 0 ? (
                <PulseButton
                  pulseColor="rose"
                  variant="glass"
                  badgeText={overdueOrders.length}
                  icon={<AlertCircle className="w-4 h-4 text-rose-500" />}
                  onClick={() => setActiveQueueTab('overdue')}
                >
                  Overdue Deliveries
                </PulseButton>
              ) : (
                <PulseButton
                  pulseColor="emerald"
                  variant="glass"
                  badgeText={upcomingDeliveries.length}
                  icon={<Check className="w-4 h-4 text-emerald-500" />}
                  onClick={() => setActiveQueueTab('upcoming')}
                >
                  Due This Week
                </PulseButton>
              )}
            </div>
          </div>

          {/* Master Tailors Avatar Stack (AvatarGroupEditable) */}
          <div className="bg-[#fafdff]/90 backdrop-blur-md rounded-2xl p-4 border border-[#dbeafe] shadow-xs flex flex-col gap-2 shrink-0">
            <div className="text-[11px] font-bold text-[#93979f] uppercase tracking-wider">
              Workshop Staff on Duty
            </div>
            <AvatarGroupEditable
              workers={state.workers}
              maxDisplay={4}
              onSelectWorker={(worker) => onNavigate('worker-page', { workerId: worker.id })}
              onManageStaff={() => onNavigate('staff-management')}
            />
            <div className="text-[10px] text-[#535862] mt-1">
              Click any tailor to inspect monthly work slips & hishab
            </div>
          </div>
        </div>
      </div>

      {/* KPI Highlight Grid (Geniestudio 32px radius Pastel Category Tiles) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Card 1: Active Production Pipeline */}
        <div className="bg-[#cce7ff]/60 rounded-[32px] p-6 border border-[#bfdbfe]/60 shadow-[0_4px_16px_rgba(0,105,224,0.04)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#1e40af] uppercase tracking-wider">Active Pipeline</span>
            <div className="w-8 h-8 rounded-full bg-white text-[#0069e0] flex items-center justify-center shadow-xs">
              <Scissors className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-medium text-[#0a0d12] tabular-nums tracking-tight">
              {totalActivePipeline}
            </div>
            <p className="text-xs text-[#535862] mt-1">
              {activeOfficerOrders.length} Officers · {activeAirmanOrders.length} Airmen
            </p>
          </div>
        </div>

        {/* Card 2: Upcoming Deliveries */}
        <div className="bg-[#fff2be]/70 rounded-[32px] p-6 border border-[#fef08a] shadow-[0_4px_16px_rgba(202,138,4,0.04)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#854d0e] uppercase tracking-wider">Due in {upcomingDays} Days</span>
            <div className="w-8 h-8 rounded-full bg-white text-[#a16207] flex items-center justify-center shadow-xs">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-medium text-[#0a0d12] tabular-nums tracking-tight">
              {upcomingDeliveries.length}
            </div>
            <p className="text-xs text-[#854d0e] font-semibold mt-1">
              {overdueOrders.length > 0 ? `⚠️ ${overdueOrders.length} orders overdue!` : 'All delivery targets on track'}
            </p>
          </div>
        </div>

        {/* Card 3: Pending Cutting Slips */}
        <div className="bg-[#f1e6ff]/70 rounded-[32px] p-6 border border-[#e4ccff] shadow-[0_4px_16px_rgba(147,51,234,0.04)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#6b21a8] uppercase tracking-wider">Pending Cutting Slips</span>
            <div className="w-8 h-8 rounded-full bg-white text-[#7e22ce] flex items-center justify-center shadow-xs">
              <Printer className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-medium text-[#0a0d12] tabular-nums tracking-tight">
              {cuttingSlipNeededOfficer.length}
            </div>
            <p className="text-xs text-[#535862] mt-1">
              Awaiting pattern cutting & tailor assignment
            </p>
          </div>
        </div>

        {/* Card 4: Outstanding Due Balance */}
        <div className="bg-[#d3f6e3]/70 rounded-[32px] p-6 border border-[#a7f3d0] shadow-[0_4px_16px_rgba(16,185,129,0.04)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#065f46] uppercase tracking-wider">Total Receivable Due</span>
            <div className="w-8 h-8 rounded-full bg-white text-[#059669] flex items-center justify-center shadow-xs">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-medium text-[#0a0d12] tabular-nums tracking-tight">
              ৳{totalOutstandingDue.toLocaleString('en-IN')}
            </div>
            <p className="text-xs text-[#065f46] font-semibold mt-1">
              Across {ordersWithDueCount} orders pending payment
            </p>
          </div>
        </div>
      </div>

      {/* Branded Section Divider */}
      <GeniestudioDivider label="Analytics & Weekly Velocity" variant="iris" />

      {/* Easy-to-understand Graph (DashboardCharts with interactive cursor) */}
      <div className="mb-8">
        <DashboardCharts
          officerOrders={state.officerOrders}
          airmanOrders={state.airmanOrders}
        />
      </div>

      {/* Branded Section Divider */}
      <GeniestudioDivider label="Workshop Folders & Document Archives" variant="pill" />

      {/* 3 Tactile Folder Containers (Folder component) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Folder 1: Officer Orders */}
        <Folder
          title="Officer Orders"
          subtitle="Commissioned officers & senior pilots"
          count={state.officerOrders.length}
          colorScheme="powder"
          icon={<ClipboardList className="w-4 h-4 text-[#0069e0]" />}
          actionText="View Officers"
          onClick={() => onNavigate('orders')}
        >
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Pending Cutting:</span>
              <span className="font-bold text-[#0a0d12]">{cuttingSlipNeededOfficer.length} orders</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Due Soon:</span>
              <span className="font-bold text-[#a16207]">{upcomingDeliveries.length} orders</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Delivered:</span>
              <span className="font-bold text-[#059669]">{recentlyDeliveredOrders.length} orders</span>
            </div>
          </div>
        </Folder>

        {/* Folder 2: Airman Orders */}
        <Folder
          title="Airman Workshop"
          subtitle="Non-commissioned airmen trade uniforms"
          count={state.airmanOrders.length}
          colorScheme="mint"
          icon={<Plane className="w-4 h-4 text-[#059669]" />}
          actionText="View Airmen"
          onClick={() => onNavigate('airman-orders')}
        >
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">In Production:</span>
              <span className="font-bold text-[#0a0d12]">{activeAirmanOrders.length} uniforms</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Trades Active:</span>
              <span className="font-bold text-[#059669]">Aircrew, Tech, Admin</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Bulk Orders:</span>
              <span className="font-bold text-[#0a0d12]">Ready for Fitting</span>
            </div>
          </div>
        </Folder>

        {/* Folder 3: Staff Monthly Hishab */}
        <Folder
          title="Staff Hishab (December)"
          subtitle="Monthly piecework & advance hishab"
          count={state.workers.length}
          colorScheme="lavender"
          icon={<Scissors className="w-4 h-4 text-[#7e22ce]" />}
          actionText="Staff Hishab"
          onClick={() => onNavigate('staff-management')}
        >
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Active Tailors:</span>
              <span className="font-bold text-[#0a0d12]">{state.workers.length} Masters</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Current Month:</span>
              <span className="font-bold text-[#7e22ce]">December 2026</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-white/70">
              <span className="text-[#535862]">Monthly Wages:</span>
              <span className="font-bold text-[#0a0d12]">Tracked Piece-rate</span>
            </div>
          </div>
        </Folder>
      </div>

      {/* Priority Workshop Queue (High-Contrast Deliveries & Cutting Slips) */}
      <div className="bg-[#fafdff] rounded-[32px] border border-white p-6 sm:p-8 shadow-[0_8px_24px_rgba(4,69,144,0.05)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-lg font-medium text-[#0a0d12] tracking-tight">
              Priority Order Queue & Fast Actions
            </h3>
            <p className="text-xs text-[#535862] mt-0.5">
              Deliver completed orders directly to clear pending cutting slips automatically
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#ebf5ff] rounded-full border border-[#dbeafe]">
            <button
              onClick={() => setActiveQueueTab('all')}
              className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                activeQueueTab === 'all'
                  ? 'bg-[#181d27] text-white shadow-xs'
                  : 'text-[#535862] hover:text-[#0a0d12]'
              }`}
            >
              All Priority ({cuttingSlipNeededOfficer.length + upcomingDeliveries.length})
            </button>
            <button
              onClick={() => setActiveQueueTab('upcoming')}
              className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                activeQueueTab === 'upcoming'
                  ? 'bg-[#181d27] text-white shadow-xs'
                  : 'text-[#535862] hover:text-[#0a0d12]'
              }`}
            >
              Upcoming ({upcomingDeliveries.length})
            </button>
            <button
              onClick={() => setActiveQueueTab('cutting')}
              className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                activeQueueTab === 'cutting'
                  ? 'bg-[#181d27] text-white shadow-xs'
                  : 'text-[#535862] hover:text-[#0a0d12]'
              }`}
            >
              Needs Cutting Slip ({cuttingSlipNeededOfficer.length})
            </button>
            {overdueOrders.length > 0 && (
              <button
                onClick={() => setActiveQueueTab('overdue')}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                  activeQueueTab === 'overdue'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-rose-600 hover:bg-rose-50'
                }`}
              >
                Overdue ({overdueOrders.length})
              </button>
            )}
            <button
              onClick={() => setActiveQueueTab('delivered')}
              className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                activeQueueTab === 'delivered'
                  ? 'bg-[#181d27] text-white shadow-xs'
                  : 'text-[#535862] hover:text-[#0a0d12]'
              }`}
            >
              Delivered ({recentlyDeliveredOrders.length})
            </button>
          </div>
        </div>

        {/* Priority List */}
        {priorityQueue.length === 0 ? (
          <div className="py-12 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
            <h4 className="text-sm font-semibold text-[#0a0d12]">Queue is clear</h4>
            <p className="text-xs text-[#535862] mt-1">
              No orders found matching the selected filter tab.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {priorityQueue.map((order) => {
              const diff = getDeliveryDiffDays(order.deliveryDate, todayStr);
              const isOverdue = diff !== null && diff < 0 && order.status !== 'Delivered';
              const isDueToday = diff === 0 && order.status !== 'Delivered';
              const isNeedsCut = order.status === 'Pending';
              const isDelivered = order.status === 'Delivered';

              return (
                <div
                  key={order.id}
                  onClick={() => onNavigate('order-details', { orderId: order.id, type: 'officer' })}
                  className={`p-4 rounded-2xl border transition-all duration-200 cursor-pointer hover:shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isOverdue
                      ? 'bg-rose-50/70 border-rose-200 hover:border-rose-400'
                      : isDueToday
                      ? 'bg-amber-50/70 border-amber-200 hover:border-amber-400'
                      : isNeedsCut
                      ? 'bg-sky-50/60 border-sky-200 hover:border-sky-400'
                      : 'bg-white border-[#dbeafe] hover:border-[#93c5fd]'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3.5">
                    {/* Order Number Badge */}
                    <div
                      className={`w-11 h-11 rounded-2xl flex flex-col items-center justify-center font-bold text-xs shrink-0 shadow-xs ${
                        isOverdue
                          ? 'bg-rose-600 text-white'
                          : isDueToday
                          ? 'bg-amber-500 text-white'
                          : 'bg-[#181d27] text-white'
                      }`}
                    >
                      <span className="text-[9px] opacity-80 uppercase leading-none">Order</span>
                      <span className="text-sm leading-tight">#{order.orderNumber}</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-[#0a0d12]">
                          {order.customerName}
                        </span>
                        {order.customerBdNumber && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#ebf5ff] text-[#0069e0]">
                            BD: {order.customerBdNumber}
                          </span>
                        )}
                        {order.branch && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-[#535862]">
                            {order.branch}
                          </span>
                        )}
                        <StatusBadge status={order.status} />
                      </div>

                      <div className="flex items-center gap-3 mt-1 text-xs text-[#535862] flex-wrap">
                        {order.deliveryDate && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-[#93979f]" />
                            <span>Delivery: <strong className="text-[#0a0d12]">{order.deliveryDate}</strong></span>
                            {isOverdue && (
                              <span className="ml-1 text-rose-600 font-bold">
                                ({Math.abs(diff!)} days overdue)
                              </span>
                            )}
                            {isDueToday && (
                              <span className="ml-1 text-amber-600 font-bold">
                                (Due Today!)
                              </span>
                            )}
                          </span>
                        )}

                        {order.items && order.items.length > 0 && (
                          <span>
                            Items: {order.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions & Financial Status */}
                  <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-black/5">
                    <div className="text-left md:text-right">
                      <div className="text-sm font-bold text-[#0a0d12] tabular-nums">
                        ৳{order.totalAmount?.toLocaleString('en-IN') || 0}
                      </div>
                      <div className="text-[11px] font-semibold">
                        {(order.due || 0) > 0 ? (
                          <span className="text-rose-600">Due: ৳{order.due}</span>
                        ) : (
                          <span className="text-emerald-600">Paid in Full</span>
                        )}
                      </div>
                    </div>

                    {/* One-Click Quick Actions */}
                    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                      {!isDelivered && (
                        <button
                          type="button"
                          onClick={(e) => handleQuickDeliver(order.orderNumber, e)}
                          className="px-3 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                          title="Mark delivered (clears from pending cutting list)"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Deliver</span>
                        </button>
                      )}

                      {isNeedsCut && (
                        <button
                          type="button"
                          onClick={(e) => handleQuickMarkCut(order.orderNumber, e)}
                          className="px-3 py-1.5 rounded-full bg-[#0069e0] hover:bg-[#0052be] text-white text-xs font-semibold shadow-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                          title="Mark cutting slip done"
                        >
                          <Scissors className="w-3.5 h-3.5" />
                          <span>Cut Done</span>
                        </button>
                      )}

                      {(order.due || 0) > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            setPayTargetOrder(order);
                            setPayAmountInput(order.due?.toString() || '');
                          }}
                          className="px-3 py-1.5 rounded-full bg-white hover:bg-[#ebf5ff] text-[#0a0d12] border border-[#dbeafe] text-xs font-semibold shadow-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                          title="Collect Due Payment"
                        >
                          <CreditCard className="w-3.5 h-3.5 text-[#0069e0]" />
                          <span>Pay Due</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => onNavigate('order-details', { orderId: order.id, type: 'officer' })}
                        className="p-1.5 rounded-full bg-white hover:bg-[#ebf5ff] text-[#535862] hover:text-[#0069e0] border border-[#dbeafe] transition-colors"
                        title="View details"
                      >
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Payment Modal */}
      {payTargetOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#fafdff] rounded-[32px] border border-white shadow-2xl max-w-md w-full p-6 text-left">
            <div className="flex items-center justify-between pb-3 border-b border-[#ebf5ff]">
              <div>
                <h3 className="text-base font-semibold text-[#0a0d12]">
                  Collect Payment · Order #{payTargetOrder.orderNumber}
                </h3>
                <p className="text-xs text-[#535862]">
                  {payTargetOrder.customerName} {payTargetOrder.branch ? `(${payTargetOrder.branch})` : ''}
                </p>
              </div>
              <button
                onClick={() => setPayTargetOrder(null)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePaySubmit} className="mt-4 space-y-4">
              <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs">
                <div className="flex justify-between font-semibold text-amber-900">
                  <span>Current Outstanding Due:</span>
                  <span className="text-sm font-bold">৳{payTargetOrder.due}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                  Amount Received (৳)
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  value={payAmountInput}
                  onChange={(e) => setPayAmountInput(e.target.value)}
                  className="w-full h-11 px-4 rounded-2xl bg-white border border-[#dbeafe] text-[#0a0d12] font-semibold text-base focus:outline-none focus:border-[#0069e0] focus:ring-2 focus:ring-[#0069e0]/20"
                  placeholder="Enter amount paid"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setPayTargetOrder(null)}
                  className="px-4 py-2 rounded-full border border-gray-200 text-xs font-semibold text-[#535862] hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-full bg-[#181d27] text-white text-xs font-semibold hover:bg-black shadow-xs"
                >
                  Confirm Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </PolarisPage>
  );
};
