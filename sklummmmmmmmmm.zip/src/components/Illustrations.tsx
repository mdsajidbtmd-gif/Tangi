import React from 'react';

/**
 * Bespoke vector SVG illustrations for Raymond tailor shop.
 * Provides crisp visual anchors, high contrast, and zero external dependency risk.
 */

export const TailorShearsIllustration: React.FC<{ className?: string }> = ({ className = 'w-24 h-24' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <circle cx="60" cy="60" r="54" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />
    {/* Right Blade */}
    <path
      d="M34 86L78 30C82 25 89 26 91 31C92 34 89 40 85 45L45 92C41 96 34 94 32 90C31 88 32 87 34 86Z"
      fill="#1E293B"
    />
    {/* Left Blade */}
    <path
      d="M86 86L42 30C38 25 31 26 29 31C28 34 31 40 35 45L75 92C79 96 86 94 88 90C89 88 88 87 86 86Z"
      fill="#334155"
    />
    {/* Pivot screw */}
    <circle cx="60" cy="58" r="5" fill="#F59E0B" stroke="#B45309" strokeWidth="1.5" />
    {/* Finger loops */}
    <circle cx="36" cy="94" r="9" fill="none" stroke="#1E293B" strokeWidth="3" />
    <circle cx="84" cy="94" r="9" fill="none" stroke="#1E293B" strokeWidth="3" />
  </svg>
);

export const UniformIllustration: React.FC<{ className?: string; category?: 'Officer' | 'Airman' }> = ({
  className = 'w-20 h-20',
  category = 'Officer',
}) => (
  <svg
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="100" height="100" rx="20" fill={category === 'Officer' ? '#0F172A' : '#1E293B'} />
    {/* Shoulder epaulettes */}
    <path d="M22 28L36 34L33 39L20 33L22 28Z" fill="#F59E0B" />
    <path d="M78 28L64 34L67 39L80 33L78 28Z" fill="#F59E0B" />
    {/* Tunic / Jacket Body */}
    <path
      d="M26 32L38 48V82H62V48L74 32L62 26H38L26 32Z"
      fill={category === 'Officer' ? '#1E293B' : '#334155'}
      stroke="#475569"
      strokeWidth="1.5"
    />
    {/* Lapels */}
    <path d="M38 26L50 48L44 54L35 38L38 26Z" fill="#3B82F6" />
    <path d="M62 26L50 48L56 54L65 38L62 26Z" fill="#3B82F6" />
    {/* Tie */}
    <path d="M48 30L52 30L53 44L50 49L47 44L48 30Z" fill="#0284C7" />
    {/* Brass buttons */}
    <circle cx="50" cy="55" r="2" fill="#FBBF24" />
    <circle cx="50" cy="63" r="2" fill="#FBBF24" />
    <circle cx="50" cy="71" r="2" fill="#FBBF24" />
    {/* Ribbons / Medal Bar */}
    <rect x="54" y="44" width="12" height="4" rx="1" fill="#DC2626" />
  </svg>
);

export const TapeMeasureIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg
    viewBox="0 0 80 80"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="80" height="80" rx="16" fill="#FEF3C7" />
    <circle cx="40" cy="40" r="26" fill="#F59E0B" />
    <circle cx="40" cy="40" r="16" fill="#D97706" />
    <path
      d="M40 24C48.8 24 56 31.2 56 40H66C66 25.6 54.4 14 40 14V24Z"
      fill="#FDE68A"
      stroke="#B45309"
      strokeWidth="1.5"
    />
    {/* Inch ticks */}
    <line x1="45" y1="16" x2="45" y2="20" stroke="#78350F" strokeWidth="1.5" />
    <line x1="50" y1="18" x2="50" y2="22" stroke="#78350F" strokeWidth="1" />
    <line x1="55" y1="21" x2="55" y2="25" stroke="#78350F" strokeWidth="1.5" />
    <line x1="60" y1="26" x2="60" y2="30" stroke="#78350F" strokeWidth="1" />
  </svg>
);

export const EmptyBoxIllustration: React.FC<{ className?: string; title?: string; subtitle?: string }> = ({
  className = 'w-24 h-24',
}) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect x="20" y="35" width="80" height="60" rx="12" fill="#F1F5F9" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="4 4" />
    <path d="M40 35V28C40 24.7 42.7 22 46 22H74C77.3 22 80 24.7 80 28V35" stroke="#94A3B8" strokeWidth="2" />
    <circle cx="60" cy="65" r="12" fill="#E2E8F0" />
    <path d="M56 65H64M60 61V69" stroke="#64748B" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const GarmentSuitIllustration: React.FC<{ className?: string }> = ({ className = 'w-24 h-24' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="120" height="120" rx="16" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="1.5" />
    {/* Hanger hook */}
    <path d="M60 22C64 22 66 26 63 29L60 32" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
    {/* Hanger body */}
    <path d="M36 42L60 32L84 42" stroke="#64748B" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    {/* Garment coat */}
    <path
      d="M40 44L48 54L38 98H82L72 54L80 44H40Z"
      fill="#1E293B"
      stroke="#0F172A"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    {/* Shirt collar & Tie */}
    <path d="M53 44L60 52L67 44H53Z" fill="#FFFFFF" />
    <path d="M58 50L62 50L63 68L60 72L57 68L58 50Z" fill="#005BD3" />
    {/* Lapels */}
    <path d="M48 44L56 68L48 54Z" fill="#334155" />
    <path d="M72 44L64 68L72 54Z" fill="#334155" />
  </svg>
);

export const PatternDraftingIllustration: React.FC<{ className?: string }> = ({ className = 'w-24 h-24' }) => (
  <svg
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="120" height="120" rx="16" fill="#F1F5F9" />
    {/* Pattern sheet */}
    <rect x="24" y="24" width="72" height="72" rx="8" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
    {/* Cutting guidelines */}
    <path d="M34 40C52 40 58 52 74 52" stroke="#94A3B8" strokeWidth="1.5" strokeDasharray="3 3" />
    <path d="M34 66C50 66 62 76 84 76" stroke="#94A3B8" strokeWidth="1.5" strokeDasharray="3 3" />
    {/* Ruler / Square */}
    <path d="M30 30V86H40V40H86V30H30Z" fill="#F59E0B" fillOpacity="0.85" />
    {/* Ruler tick marks */}
    <line x1="34" y1="46" x2="38" y2="46" stroke="#78350F" strokeWidth="1" />
    <line x1="34" y1="56" x2="38" y2="56" stroke="#78350F" strokeWidth="1" />
    <line x1="34" y1="66" x2="38" y2="66" stroke="#78350F" strokeWidth="1" />
    <line x1="34" y1="76" x2="38" y2="76" stroke="#78350F" strokeWidth="1" />
    <line x1="46" y1="34" x2="46" y2="38" stroke="#78350F" strokeWidth="1" />
    <line x1="56" y1="34" x2="56" y2="38" stroke="#78350F" strokeWidth="1" />
    <line x1="66" y1="34" x2="66" y2="38" stroke="#78350F" strokeWidth="1" />
    <line x1="76" y1="34" x2="76" y2="38" stroke="#78350F" strokeWidth="1" />
  </svg>
);

