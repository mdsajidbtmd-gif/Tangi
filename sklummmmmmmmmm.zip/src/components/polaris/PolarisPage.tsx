import React from 'react';
import { ArrowLeft } from 'lucide-react';

export interface ActionItem {
  label?: string;
  content?: string;
  onClick?: () => void;
  onAction?: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PolarisPageProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  backAction?: () => void;
  primaryAction?: ActionItem;
  secondaryActions?: ActionItem[];
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const PolarisPage: React.FC<PolarisPageProps> = ({
  title,
  subtitle,
  badge,
  backAction,
  primaryAction,
  secondaryActions = [],
  children,
  fullWidth = false,
}) => {
  return (
    <div className="min-h-full text-[#303030] pb-12">
      {/* Max Width Container */}
      <div className={`mx-auto space-y-4 ${fullWidth ? 'max-w-7xl' : 'max-w-[1000px]'}`}>
        {/* Page Header (Title 20/28, 650 weight) */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-1">
          {/* Left: Back Arrow + Title + Badge */}
          <div className="flex items-center space-x-3">
            {backAction && (
              <button
                onClick={backAction}
                className="w-7 h-7 rounded-[8px] flex items-center justify-center text-[#303030] hover:bg-black/5 border border-[#E3E3E3] bg-white transition-colors cursor-pointer shrink-0"
                aria-label="Back"
              >
                <ArrowLeft className="w-4 h-4 stroke-[2]" />
              </button>
            )}
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-[20px] leading-[28px] font-[650] text-[#1A1A1A] tracking-normal">
                  {title}
                </h1>
                {badge && <div className="shrink-0">{badge}</div>}
              </div>
              {subtitle && (
                <p className="text-[13px] leading-[20px] text-[#616161] font-[450] mt-0.5">
                  {subtitle}
                </p>
              )}
            </div>
          </div>

          {/* Right: Actions Cluster (One Primary near-black + Secondaries in #E3E3E3) */}
          {(secondaryActions.length > 0 || primaryAction) && (
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {secondaryActions.map((action, idx) => {
                const clickHandler = action.onClick || action.onAction;
                const text = action.label || action.content;
                return (
                  <button
                    key={idx}
                    onClick={clickHandler}
                    disabled={action.disabled}
                    className="h-[28px] px-3 rounded-[8px] bg-[#E3E3E3] hover:bg-[#D4D4D4] text-[#303030] text-[13px] font-[550] inline-flex items-center space-x-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {action.icon && <span className="w-3.5 h-3.5 text-[#303030]">{action.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })}

              {primaryAction && (() => {
                const clickHandler = primaryAction.onClick || primaryAction.onAction;
                const text = primaryAction.label || primaryAction.content;
                return (
                  <button
                    onClick={clickHandler}
                    disabled={primaryAction.disabled}
                    className="h-[28px] px-3 rounded-[8px] bg-[#303030] hover:bg-[#1A1A1A] text-white text-[13px] font-[550] inline-flex items-center space-x-1.5 border border-[#1A1A1A] shadow-xs disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  >
                    {primaryAction.icon && <span className="w-3.5 h-3.5 stroke-[2]">{primaryAction.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })()}
            </div>
          )}
        </div>

        {/* Content Region */}
        <div className="space-y-4">{children}</div>
      </div>
    </div>
  );
};
