import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
} from 'lucide-react';

interface SidebarProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();

  const draftsCount = state.drafts.length;

  const navItems: {
    id: ScreenName;
    label: string;
    icon: React.ComponentType<{ className?: string; fill?: string; strokeWidth?: number }>;
    badge?: number;
    activeScreenMatches?: ScreenName[];
  }[] = [
    {
      id: 'dashboard',
      label: 'Home',
      icon: LayoutDashboard,
    },
    {
      id: 'orders',
      label: 'Officer Orders',
      icon: ClipboardList,
      activeScreenMatches: ['new-officer-order', 'edit-officer-order', 'order-details'],
    },
    {
      id: 'airman-orders',
      label: 'Airman Orders',
      icon: Plane,
      activeScreenMatches: ['new-airman-order', 'edit-airman-order'],
    },
    {
      id: 'delivery',
      label: 'Delivery',
      icon: Truck,
    },
    {
      id: 'drafts',
      label: 'Drafts',
      icon: FileText,
      badge: draftsCount > 0 ? draftsCount : undefined,
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
    },
    {
      id: 'customer-history',
      label: 'Customer History',
      icon: History,
    },
    {
      id: 'staff-management',
      label: 'Staff Management',
      icon: UserCheck,
      activeScreenMatches: ['worker-page'],
    },
    {
      id: 'staff-summary',
      label: 'Staff Summary',
      icon: BarChart3,
      activeScreenMatches: ['worker-history'],
    },
  ];

  const handleItemClick = (id: ScreenName) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const isSelected = (item: typeof navItems[0]) => {
    if (currentScreen === item.id) return true;
    if (item.activeScreenMatches && item.activeScreenMatches.includes(currentScreen)) {
      return true;
    }
    return false;
  };

  const isSettingsSelected = currentScreen === 'settings';

  return (
    <>
      {/* Mobile Drawer Overlay / Scrim */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:sticky top-0 md:top-[56px] z-50 md:z-20 h-screen md:h-[calc(100vh-56px)] w-[240px] bg-[#EBEBEB] text-[#303030] flex flex-col justify-between py-3 px-3 transition-transform duration-200 select-none border-r border-[#E3E3E3] shrink-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
        style={{ width: 'var(--sidebar-w)', backgroundColor: 'var(--surface-sidebar)' }}
        aria-label="Main navigation"
      >
        {/* Top: Mobile Close button + Primary Nav Group */}
        <div className="flex flex-col space-y-1">
          {/* Mobile Header */}
          <div className="flex items-center justify-between pb-2 mb-1 border-b border-[#D4D4D4] md:hidden">
            <span className="font-semibold text-xs text-[#616161]">Navigation</span>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-1 rounded-md text-[#616161] hover:text-[#303030] hover:bg-black/5"
              aria-label="Close navigation"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Primary Nav Items */}
          <nav className="space-y-0.5">
            {navItems.map((item) => {
              const active = isSelected(item);
              const Icon = item.icon;

              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`w-full h-[28px] px-2 rounded-[8px] flex items-center justify-between transition-colors text-[13px] leading-[20px] cursor-pointer group ${
                    active
                      ? 'bg-[#FAFAFA] text-[#000000] font-[550] shadow-2xs'
                      : 'text-[#303030] font-[450] hover:bg-black/5 hover:text-[#000000]'
                  }`}
                >
                  <div className="flex items-center space-x-2 truncate">
                    {/* Reverse Icon Rule: Unselected = filled glyph, Selected = outline glyph */}
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        active ? 'text-[#000000]' : 'text-[#3A3A3A]'
                      }`}
                      fill={active ? 'none' : 'currentColor'}
                      strokeWidth={active ? 1.9 : 1.4}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {/* Badge */}
                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`text-[11px] font-[550] px-1.5 py-0.2 rounded-full leading-none ${
                        active
                          ? 'bg-[#E3E3E3] text-[#303030]'
                          : 'bg-[#D4D4D4] text-[#303030]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom / Footer: Settings Pinned to Bottom (20px above window edge) */}
        <div className="pt-2 border-t border-[#D4D4D4] mb-2">
          <button
            onClick={() => handleItemClick('settings')}
            aria-current={isSettingsSelected ? 'page' : undefined}
            className={`w-full h-[28px] px-2 rounded-[8px] flex items-center space-x-2 transition-colors text-[13px] leading-[20px] cursor-pointer ${
              isSettingsSelected
                ? 'bg-[#FAFAFA] text-[#000000] font-[550] shadow-2xs'
                : 'text-[#303030] font-[450] hover:bg-black/5 hover:text-[#000000]'
            }`}
          >
            <Settings
              className={`w-4 h-4 shrink-0 ${
                isSettingsSelected ? 'text-[#000000]' : 'text-[#3A3A3A]'
              }`}
              fill={isSettingsSelected ? 'none' : 'currentColor'}
              strokeWidth={isSettingsSelected ? 1.9 : 1.4}
            />
            <span>Settings</span>
          </button>
        </div>
      </aside>
    </>
  );
};
