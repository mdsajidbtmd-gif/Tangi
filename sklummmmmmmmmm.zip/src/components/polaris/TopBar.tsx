import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  Scissors,
  Search,
  Bell,
  Menu,
  X,
} from 'lucide-react';

interface TopBarProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
  onOpenSearch: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onNavigate,
  onOpenSearch,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();

  // Calculate urgent/attention count for notification bell
  const upcomingCount = state.officerOrders.filter((o) => {
    if (o.status === 'Delivered') return false;
    if (!o.deliveryDate) return false;
    const diff = (new Date(o.deliveryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    return diff >= 0 && diff <= (state.settings.upcomingDeliveryDays || 3);
  }).length;

  const dueCount = state.officerOrders.filter(
    (o) => o.status === 'Delivered' && o.due > 0
  ).length;

  const alertCount = upcomingCount + dueCount;

  return (
    <header
      className="h-[56px] bg-[#1A1A1A] text-white flex items-center justify-between px-3 sm:px-4 sticky top-0 z-40 select-none print:hidden border-b border-[#1A1A1A]"
      style={{ height: 'var(--topbar-h)' }}
    >
      {/* Left: Brand Lockup & Mobile Hamburger */}
      <div className="flex items-center space-x-2.5 min-w-[200px]">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-1.5 text-[#B5B5B5] hover:text-white rounded-lg hover:bg-[#303030] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div
          onClick={() => onNavigate('dashboard')}
          className="flex items-center space-x-2 cursor-pointer group"
          title="Raymond - BAF Tailor Studio"
        >
          {/* White monogram mark */}
          <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center text-white border border-white/15 group-hover:bg-white/20 transition-all">
            <Scissors className="w-4 h-4 transform -rotate-45" />
          </div>
          <div className="leading-tight">
            <span className="font-semibold text-white text-[14px] tracking-tight block">
              Raymond
            </span>
            <span className="text-[11px] text-[#B5B5B5] font-normal tracking-tight block">
              BAF Tailor Studio
            </span>
          </div>
        </div>
      </div>

      {/* Center: Global Search Bar (Shopify Admin 36px Centered Field with Cmd+K) */}
      <div className="flex-1 max-w-[650px] mx-2 sm:mx-6">
        <button
          onClick={onOpenSearch}
          className="w-full h-[36px] rounded-[16px] bg-[#303030] hover:bg-[#3A3A3A] transition-all flex items-center justify-between px-3 text-[#B5B5B5] border-0 focus:outline-none focus:ring-2 focus:ring-[#005BD3] text-[13px] cursor-pointer group"
          aria-label="Global search (Cmd + K)"
        >
          <div className="flex items-center space-x-2.5 truncate">
            <Search className="w-4 h-4 text-[#B5B5B5] group-hover:text-white transition-colors" />
            <span className="truncate text-[13px] font-normal text-[#B5B5B5]">
              Search orders, customers, tailors, BD...
            </span>
          </div>
          <div className="flex items-center space-x-1 shrink-0 ml-2">
            <kbd className="min-w-[20px] h-5 px-1.5 rounded-[4px] bg-[#3A3A3A] text-[#B5B5B5] text-[11px] font-medium flex items-center justify-center">
              ⌘
            </kbd>
            <kbd className="min-w-[20px] h-5 px-1.5 rounded-[4px] bg-[#3A3A3A] text-[#B5B5B5] text-[11px] font-medium flex items-center justify-center">
              K
            </kbd>
          </div>
        </button>
      </div>

      {/* Right: Notifications Bell & Store Switcher */}
      <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
        {/* Notifications Bell */}
        <button
          onClick={() => onNavigate('delivery')}
          className="relative p-2 rounded-lg text-[#B5B5B5] hover:text-white hover:bg-[#303030] transition-colors focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
          title={alertCount > 0 ? `${alertCount} orders requiring attention` : 'Delivery notifications'}
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {alertCount > 0 && (
            <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-[#D72C35] text-white text-[10px] font-semibold flex items-center justify-center">
              {alertCount > 9 ? '9+' : alertCount}
            </span>
          )}
        </button>

        {/* Store / Workspace Switcher (28px rounded-square avatar with lime fill) */}
        <div
          onClick={() => onNavigate('settings')}
          className="flex items-center space-x-2 cursor-pointer p-1 rounded-lg hover:bg-[#303030] transition-colors"
          title="Raymond Studio (Store Settings)"
        >
          <div className="w-7 h-7 rounded-[8px] bg-[#22EB23] text-[#1A1A1A] font-semibold text-[13px] flex items-center justify-center shrink-0 shadow-2xs">
            RT
          </div>
          <span className="hidden lg:inline-block text-[13px] font-[550] text-white">
            Raymond
          </span>
        </div>
      </div>
    </header>
  );
};
