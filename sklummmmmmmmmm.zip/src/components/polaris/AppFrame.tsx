import React, { useState } from 'react';
import { ScreenName } from '../Navbar.tsx';
import { TopBar } from './TopBar.tsx';
import { Sidebar } from './Sidebar.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { OfflineIndicator } from '../OfflineIndicator.tsx';
import { LayoutDashboard, ClipboardList, Plane, Truck, Settings } from 'lucide-react';

interface AppFrameProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  children: React.ReactNode;
}

export const AppFrame: React.FC<AppFrameProps> = ({
  currentScreen,
  onNavigate,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  const isOfficerActive =
    currentScreen === 'orders' ||
    currentScreen === 'new-officer-order' ||
    currentScreen === 'edit-officer-order' ||
    currentScreen === 'order-details';

  const isAirmanActive =
    currentScreen === 'airman-orders' ||
    currentScreen === 'new-airman-order' ||
    currentScreen === 'edit-airman-order';

  const isDashboardActive = currentScreen === 'dashboard';

  return (
    <div className="min-h-screen bg-[#1A1A1A] flex flex-col font-sans selection:bg-[#005BD3] selection:text-white pb-16 md:pb-0">
      {/* 56px TopBar */}
      <TopBar
        onNavigate={onNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Main Body with tucked 12px top-left corner */}
      <div className="flex-1 flex bg-[#F1F1F1] md:rounded-tl-[12px] overflow-hidden min-h-0">
        {/* Persistent Desktop Sidebar */}
        <Sidebar
          currentScreen={currentScreen}
          onNavigate={onNavigate}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />

        {/* Main Canvas with 24px padding */}
        <main
          className="flex-1 overflow-y-auto min-w-0 bg-[#F1F1F1] p-4 sm:p-6 lg:p-6"
          style={{ backgroundColor: 'var(--surface-canvas)' }}
        >
          {children}
        </main>
      </div>

      {/* Global Search Modal (Cmd + K) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Offline Status Pill */}
      <OfflineIndicator />

      {/* Mobile Bottom Tab Bar (< 768px only, strictly hidden on md+) */}
      <div className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-[#E1E3E5] safe-area-bottom">
        <nav
          className="h-14 flex items-center justify-around px-2"
          aria-label="Mobile Navigation"
        >
          <button
            onClick={() => onNavigate('dashboard')}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              isDashboardActive ? 'text-[#008060] font-semibold' : 'text-[#6D7175]'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" strokeWidth={isDashboardActive ? 2.2 : 1.6} />
            <span className="text-[11px] mt-0.5 leading-none">Home</span>
          </button>

          <button
            onClick={() => onNavigate('orders')}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              isOfficerActive ? 'text-[#008060] font-semibold' : 'text-[#6D7175]'
            }`}
          >
            <ClipboardList className="w-5 h-5" strokeWidth={isOfficerActive ? 2.2 : 1.6} />
            <span className="text-[11px] mt-0.5 leading-none">Officers</span>
          </button>

          <button
            onClick={() => onNavigate('airman-orders')}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              isAirmanActive ? 'text-[#008060] font-semibold' : 'text-[#6D7175]'
            }`}
          >
            <Plane className="w-5 h-5" strokeWidth={isAirmanActive ? 2.2 : 1.6} />
            <span className="text-[11px] mt-0.5 leading-none">Airman</span>
          </button>

          <button
            onClick={() => onNavigate('delivery')}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              currentScreen === 'delivery' ? 'text-[#008060] font-semibold' : 'text-[#6D7175]'
            }`}
          >
            <Truck className="w-5 h-5" strokeWidth={currentScreen === 'delivery' ? 2.2 : 1.6} />
            <span className="text-[11px] mt-0.5 leading-none">Delivery</span>
          </button>

          <button
            onClick={() => onNavigate('settings')}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
              currentScreen === 'settings' ? 'text-[#008060] font-semibold' : 'text-[#6D7175]'
            }`}
          >
            <Settings className="w-5 h-5" strokeWidth={currentScreen === 'settings' ? 2.2 : 1.6} />
            <span className="text-[11px] mt-0.5 leading-none">Settings</span>
          </button>
        </nav>
      </div>
    </div>
  );
};
