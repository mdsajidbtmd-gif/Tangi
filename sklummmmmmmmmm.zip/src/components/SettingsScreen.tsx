import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { GeniestudioDivider } from './elements/GeniestudioDivider.tsx';
import {
  Settings,
  Scissors,
  Store,
  Clock,
  ShieldCheck,
  Save,
  Download,
  CheckCircle2,
} from 'lucide-react';

export const SettingsScreen: React.FC = () => {
  const { state, updateSettings } = useApp();
  const [shopName, setShopName] = useState(state.settings.invoiceShopName || 'Raymond');
  const [phone, setPhone] = useState(state.settings.invoiceShopPhone || '01711-000000');
  const [address, setAddress] = useState(
    state.settings.invoiceShopAddress || 'BAF Base Tailor Market, Dhaka Cantonment'
  );
  const [upcomingDays, setUpcomingDays] = useState(
    state.settings.upcomingDeliveryDays || 3
  );
  const [savedToast, setSavedToast] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      invoiceShopName: shopName,
      invoiceShopPhone: phone,
      invoiceShopAddress: address,
      upcomingDeliveryDays: Number(upcomingDays),
    });
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raymond-tailor-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <PolarisPage
      title="Tailor Workshop Settings"
      subtitle="Configure shop branding, delivery alert thresholds, and data backup"
    >
      {savedToast && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-900 flex items-center gap-2.5 animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span className="text-sm font-semibold">Settings successfully updated!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Studio Branding Card */}
        <PolarisCard
          title="Tailor Studio Profile"
          subtitle="Branding used across officer cutting slips and delivery receipts"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                Shop / Studio Name
              </label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full h-11 px-4 rounded-2xl bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                placeholder="e.g. Raymond"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                Contact Phone
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full h-11 px-4 rounded-2xl bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                placeholder="e.g. 01711-xxxxxx"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                Workshop Location / Cantonment Address
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full h-11 px-4 rounded-2xl bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                placeholder="BAF Base Tailor Market, Dhaka"
              />
            </div>
          </div>
        </PolarisCard>

        {/* Operational Thresholds */}
        <PolarisCard
          title="Delivery Thresholds"
          subtitle="Configure upcoming delivery reminders and workshop velocity triggers"
        >
          <div className="max-w-md">
            <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
              Upcoming Delivery Warning Horizon (Days)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="1"
                max="14"
                value={upcomingDays}
                onChange={(e) => setUpcomingDays(Number(e.target.value))}
                className="w-24 h-11 px-4 rounded-2xl bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-semibold text-center focus:bg-white focus:outline-none focus:border-[#0069e0]"
              />
              <span className="text-xs text-[#535862]">
                Orders with delivery dates within this window trigger high-contrast warning pills
              </span>
            </div>
          </div>
        </PolarisCard>

        {/* Data Security & Backup */}
        <PolarisCard
          title="Backup & System Data"
          subtitle="Safeguard order history, measurements, and staff piecework hishab"
        >
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleExportData}
              className="px-4 py-2.5 rounded-full bg-[#ebf5ff] hover:bg-[#dbeafe] text-[#0069e0] text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Export Full Studio Backup (JSON)</span>
            </button>
          </div>
        </PolarisCard>

        {/* Save CTA */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-full bg-[#181d27] hover:bg-[#0a0d12] text-white text-sm font-semibold shadow-[0_1px_2px_rgba(10,13,18,0.8),0_0_0_1px_#0a0d12] flex items-center gap-2 transition-all cursor-pointer active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>Save Workshop Settings</span>
          </button>
        </div>
      </form>
    </PolarisPage>
  );
};
