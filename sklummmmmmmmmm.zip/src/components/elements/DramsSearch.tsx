import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Search, X, Command, ArrowRight, User, Plane, Scissors, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';

interface DramsSearchProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
  className?: string;
  variant?: 'compact' | 'expanded';
  placeholder?: string;
}

export const DramsSearch: React.FC<DramsSearchProps> = ({
  onNavigate,
  className = '',
  variant = 'compact',
  placeholder = 'Search officer, airman, order #, or hishab...',
}) => {
  const { state } = useApp();
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'All' | 'Officers' | 'Airmen' | 'Tailors'>('All');
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard shortcut (⌘K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
        inputRef.current?.focus();
      } else if (e.key === 'Escape') {
        setIsOpen(false);
        inputRef.current?.blur();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filtered search results
  const searchResults = useMemo(() => {
    if (!query.trim()) return { officers: [], airmen: [], workers: [] };
    const q = query.toLowerCase().trim();

    const officers = (activeFilter === 'All' || activeFilter === 'Officers')
      ? state.officerOrders
          .filter((o) =>
            o.customerName.toLowerCase().includes(q) ||
            o.orderNumber.toString().includes(q) ||
            (o.customerBdNumber && o.customerBdNumber.toLowerCase().includes(q)) ||
            (o.customerPhone && o.customerPhone.includes(q)) ||
            (o.branch && o.branch.toLowerCase().includes(q))
          )
          .slice(0, 5)
      : [];

    const airmen = (activeFilter === 'All' || activeFilter === 'Airmen')
      ? state.airmanOrders
          .filter((a) =>
            a.customerName.toLowerCase().includes(q) ||
            a.trade.toLowerCase().includes(q) ||
            a.orderNumber.toString().includes(q) ||
            (a.customerBdNumber && a.customerBdNumber.toLowerCase().includes(q)) ||
            (a.customerPhone && a.customerPhone.includes(q))
          )
          .slice(0, 5)
      : [];

    const workers = (activeFilter === 'All' || activeFilter === 'Tailors')
      ? state.workers
          .filter((w) =>
            w.name.toLowerCase().includes(q) ||
            (w.banglaName && w.banglaName.includes(q))
          )
          .slice(0, 3)
      : [];

    return { officers, airmen, workers };
  }, [query, activeFilter, state.officerOrders, state.airmanOrders, state.workers]);

  const hasResults =
    searchResults.officers.length > 0 ||
    searchResults.airmen.length > 0 ||
    searchResults.workers.length > 0;

  return (
    <div ref={containerRef} className={`relative select-none ${className}`}>
      {/* Search Input Bar (Framer DramsSearch styling) */}
      <div
        onClick={() => {
          setIsOpen(true);
          inputRef.current?.focus();
        }}
        className={`relative flex items-center bg-white/90 hover:bg-white border transition-all duration-200 backdrop-blur-md rounded-full shadow-[0_2px_12px_rgba(4,69,144,0.06)] hover:shadow-[0_4px_18px_rgba(4,69,144,0.1)] cursor-text group ${
          isOpen ? 'border-[#0069e0] ring-3 ring-[#0069e0]/15' : 'border-[#dbeafe]'
        } ${variant === 'expanded' ? 'h-12 px-4' : 'h-10 px-3.5'}`}
      >
        <Search className={`w-4 h-4 shrink-0 transition-colors ${isOpen ? 'text-[#0069e0]' : 'text-[#535862] group-hover:text-[#0069e0]'}`} />

        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className="w-full bg-transparent px-3 text-xs sm:text-sm text-[#0a0d12] placeholder-[#93979f] focus:outline-none"
        />

        {query ? (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setQuery('');
              inputRef.current?.focus();
            }}
            className="p-1 hover:bg-[#ebf5ff] rounded-full text-[#535862] hover:text-[#0a0d12]"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : (
          <div className="hidden sm:flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-[#ebf5ff] border border-[#dbeafe] text-[10px] font-medium text-[#535862]">
            <Command className="w-2.5 h-2.5 text-[#0069e0]" />
            <span>K</span>
          </div>
        )}
      </div>

      {/* Dropdown Search Results Overlay */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-2 bg-[#fafdff] rounded-[28px] border border-[#dbeafe] shadow-[0_16px_40px_rgba(4,69,144,0.12)] p-3.5 z-50 animate-in fade-in zoom-in-95 duration-150">
          {/* Quick Filter Pills */}
          <div className="flex items-center gap-1.5 pb-2.5 mb-2 border-b border-[#ebf5ff] overflow-x-auto no-scrollbar">
            {(['All', 'Officers', 'Airmen', 'Tailors'] as const).map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                  activeFilter === filter
                    ? 'bg-[#181d27] text-white shadow-xs'
                    : 'bg-[#ebf5ff]/70 hover:bg-[#ebf5ff] text-[#535862] hover:text-[#0a0d12]'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Results List */}
          <div className="max-h-80 overflow-y-auto space-y-3 pr-1">
            {!query.trim() && (
              <div className="p-4 text-center">
                <p className="text-xs text-[#535862]">
                  Type an order number (e.g. <span className="font-semibold text-[#0069e0]">12</span>), officer rank, BD number, or tailor name.
                </p>
                <div className="mt-3 flex flex-wrap gap-2 justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      setIsOpen(false);
                      onNavigate('new-officer-order');
                    }}
                    className="px-3 py-1.5 rounded-full bg-[#ebf5ff] hover:bg-[#dbeafe] text-[#0069e0] text-xs font-semibold"
                  >
                    + New Officer Order
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsOpen(false);
                      onNavigate('new-airman-order');
                    }}
                    className="px-3 py-1.5 rounded-full bg-[#ebf5ff] hover:bg-[#dbeafe] text-[#0069e0] text-xs font-semibold"
                  >
                    + New Airman Order
                  </button>
                </div>
              </div>
            )}

            {query.trim() && !hasResults && (
              <div className="py-6 text-center text-xs text-[#93979f]">
                No orders or staff found matching "{query}".
              </div>
            )}

            {/* Officer Orders Section */}
            {searchResults.officers.length > 0 && (
              <div>
                <div className="text-[10px] font-bold text-[#93979f] uppercase tracking-wider px-2 mb-1 flex items-center gap-1.5">
                  <User className="w-3 h-3 text-[#0069e0]" />
                  <span>Officer Orders</span>
                </div>
                <div className="space-y-1">
                  {searchResults.officers.map((order) => (
                    <button
                      key={order.id}
                      type="button"
                      onClick={() => {
                        setIsOpen(false);
                        onNavigate('order-details', { orderId: order.id, type: 'officer' });
                      }}
                      className="w-full flex items-center justify-between p-2 rounded-2xl hover:bg-[#ebf5ff] text-left transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-full bg-[#cce7ff] text-[#0069e0] font-bold text-xs flex items-center justify-center">
                          #{order.orderNumber}
                        </span>
                        <div>
                          <div className="text-xs font-bold text-[#0a0d12] group-hover:text-[#0069e0]">
                            {order.customerName}
                          </div>
                          <div className="text-[10px] text-[#535862]">
                            BD: {order.customerBdNumber || 'N/A'} {order.branch ? `· ${order.branch}` : ''} · Delivery: {order.deliveryDate || 'TBD'}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold text-[#0a0d12]">
                          ৳{order.totalAmount?.toLocaleString('en-IN') || 0}
                        </span>
                        <div className="text-[10px] text-[#0069e0] group-hover:underline flex items-center gap-0.5 justify-end">
                          <span>View</span>
                          <ArrowRight className="w-2.5 h-2.5" />
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Airman Orders Section */}
            {searchResults.airmen.length > 0 && (
              <div>
                <div className="text-[10px] font-bold text-[#93979f] uppercase tracking-wider px-2 mb-1 flex items-center gap-1.5">
                  <Plane className="w-3 h-3 text-[#0069e0]" />
                  <span>Airman Orders</span>
                </div>
                <div className="space-y-1">
                  {searchResults.airmen.map((order) => (
                    <button
                      key={order.id}
                      type="button"
                      onClick={() => {
                        setIsOpen(false);
                        onNavigate('airman-orders', { search: order.orderNumber.toString() });
                      }}
                      className="w-full flex items-center justify-between p-2 rounded-2xl hover:bg-[#ebf5ff] text-left transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-full bg-[#d3f6e3] text-[#047857] font-bold text-xs flex items-center justify-center">
                          #{order.orderNumber}
                        </span>
                        <div>
                          <div className="text-xs font-bold text-[#0a0d12] group-hover:text-[#0069e0]">
                            {order.customerName}
                          </div>
                          <div className="text-[10px] text-[#535862]">
                            Trade: {order.trade || 'General'} · BD: {order.customerBdNumber || 'N/A'}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold text-[#0a0d12]">
                          {order.items?.length || 1} items
                        </span>
                        <div className="text-[10px] text-[#0069e0] group-hover:underline flex items-center gap-0.5 justify-end">
                          <span>View</span>
                          <ArrowRight className="w-2.5 h-2.5" />
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Tailor Staff Section */}
            {searchResults.workers.length > 0 && (
              <div>
                <div className="text-[10px] font-bold text-[#93979f] uppercase tracking-wider px-2 mb-1 flex items-center gap-1.5">
                  <Scissors className="w-3 h-3 text-[#0069e0]" />
                  <span>Tailors & Staff</span>
                </div>
                <div className="space-y-1">
                  {searchResults.workers.map((worker) => (
                    <button
                      key={worker.id}
                      type="button"
                      onClick={() => {
                        setIsOpen(false);
                        onNavigate('worker-page', { workerId: worker.id });
                      }}
                      className="w-full flex items-center justify-between p-2 rounded-2xl hover:bg-[#ebf5ff] text-left transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-full bg-[#f1e6ff] text-[#7e22ce] font-bold text-xs flex items-center justify-center">
                          {worker.name.slice(0, 2).toUpperCase()}
                        </span>
                        <div>
                          <div className="text-xs font-bold text-[#0a0d12] group-hover:text-[#0069e0]">
                            {worker.name}
                          </div>
                          <div className="text-[10px] text-[#535862]">
                            {worker.banglaName || 'Tailor Master'} · {worker.active ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                      </div>
                      <span className="text-xs font-semibold text-[#0069e0]">Open Hishab →</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
