import React from 'react';

interface PulseButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  badgeText?: string | number;
  pulseColor?: 'amber' | 'emerald' | 'blue' | 'rose';
  variant?: 'solid' | 'glass' | 'subtle';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export const PulseButton: React.FC<PulseButtonProps> = ({
  badgeText,
  pulseColor = 'amber',
  variant = 'glass',
  size = 'md',
  icon,
  children,
  className = '',
  ...props
}) => {
  const pulseColors = {
    amber: {
      dot: 'bg-amber-500',
      halo: 'bg-amber-400/50',
      glow: 'shadow-[0_0_12px_rgba(245,158,11,0.35)]',
      border: 'border-amber-200/80',
    },
    emerald: {
      dot: 'bg-emerald-500',
      halo: 'bg-emerald-400/50',
      glow: 'shadow-[0_0_12px_rgba(16,185,129,0.35)]',
      border: 'border-emerald-200/80',
    },
    blue: {
      dot: 'bg-[#0069e0]',
      halo: 'bg-sky-400/50',
      glow: 'shadow-[0_0_12px_rgba(0,105,224,0.35)]',
      border: 'border-sky-200/80',
    },
    rose: {
      dot: 'bg-rose-500',
      halo: 'bg-rose-400/50',
      glow: 'shadow-[0_0_12px_rgba(244,63,94,0.35)]',
      border: 'border-rose-200/80',
    },
  };

  const selectedPulse = pulseColors[pulseColor];

  const sizeStyles = {
    sm: 'text-xs py-1.5 px-3.5 gap-2',
    md: 'text-sm py-2 px-4.5 gap-2.5',
    lg: 'text-base py-2.5 px-6 gap-3',
  };

  const variantStyles = {
    glass:
      'bg-white/85 hover:bg-white text-[#0a0d12] border border-white/90 shadow-[0_2px_10px_rgba(0,0,0,0.04)] hover:shadow-[0_6px_20px_rgba(0,0,0,0.08)] backdrop-blur-md',
    solid:
      'bg-[#181d27] hover:bg-[#0a0d12] text-white border border-[#181d27] shadow-[0_1px_2px_rgba(10,13,18,0.8),0_0_0_1px_#0a0d12]',
    subtle:
      'bg-[#fafdff] hover:bg-[#ebf5ff] text-[#0a0d12] border border-[#dbeafe]',
  };

  return (
    <button
      className={`relative inline-flex items-center justify-center font-medium tracking-tight rounded-full transition-all duration-200 active:scale-95 select-none overflow-hidden group ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {/* Animated Live Pulse Beacon */}
      <span className="relative flex h-2.5 w-2.5 shrink-0">
        <span
          className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${selectedPulse.dot}`}
        />
        <span
          className={`relative inline-flex rounded-full h-2.5 w-2.5 ${selectedPulse.dot}`}
        />
      </span>

      {icon && <span className="shrink-0 transition-transform duration-200 group-hover:scale-110">{icon}</span>}

      <span className="relative z-10">{children}</span>

      {badgeText !== undefined && (
        <span
          className={`ml-1 px-2 py-0.5 text-[11px] font-semibold rounded-full ${
            variant === 'solid'
              ? 'bg-white/20 text-white'
              : 'bg-[#ebf5ff] text-[#0069e0]'
          }`}
        >
          {badgeText}
        </span>
      )}
    </button>
  );
};
